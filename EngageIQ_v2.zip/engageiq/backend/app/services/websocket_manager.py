"""
WebSocket Connection Manager
Manages real-time connections for:
  - Student webcam feed -> ML inference -> CES
  - Teacher dashboard <- live engagement broadcast
"""
import asyncio
import json
import logging
import base64
from typing import Dict, Set, Optional
from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self):
        self.teacher_connections: Dict[str, Set[WebSocket]] = {}
        self.student_connections: Dict[str, Dict[str, WebSocket]] = {}

    async def connect_teacher(self, websocket: WebSocket, session_id: str):
        await websocket.accept()
        if session_id not in self.teacher_connections:
            self.teacher_connections[session_id] = set()
        self.teacher_connections[session_id].add(websocket)
        logger.info("Teacher connected to session %s", session_id)

    def disconnect_teacher(self, websocket: WebSocket, session_id: str):
        if session_id in self.teacher_connections:
            self.teacher_connections[session_id].discard(websocket)
            if not self.teacher_connections[session_id]:
                del self.teacher_connections[session_id]

    async def broadcast_to_teachers(self, session_id: str, data: dict):
        if session_id not in self.teacher_connections:
            return
        dead = set()
        message = json.dumps(data)
        for ws in self.teacher_connections[session_id]:
            try:
                await ws.send_text(message)
            except Exception:
                dead.add(ws)
        for ws in dead:
            self.teacher_connections[session_id].discard(ws)

    async def connect_student(self, websocket: WebSocket, session_id: str, student_label: str):
        await websocket.accept()
        if session_id not in self.student_connections:
            self.student_connections[session_id] = {}
        self.student_connections[session_id][student_label] = websocket
        logger.info("Student '%s' connected to session %s", student_label, session_id)

    def disconnect_student(self, session_id: str, student_label: str):
        if session_id in self.student_connections:
            self.student_connections[session_id].pop(student_label, None)
            if not self.student_connections[session_id]:
                del self.student_connections[session_id]

    def get_active_students(self, session_id: str) -> list:
        return list(self.student_connections.get(session_id, {}).keys())

    def get_teacher_count(self, session_id: str) -> int:
        return len(self.teacher_connections.get(session_id, set()))


_manager: Optional[ConnectionManager] = None


def get_connection_manager() -> ConnectionManager:
    global _manager
    if _manager is None:
        _manager = ConnectionManager()
    return _manager
