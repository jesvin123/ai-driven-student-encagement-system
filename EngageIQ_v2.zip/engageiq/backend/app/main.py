import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.database import create_tables
from app.routes.auth import router as auth_router
from app.routes.sessions import router as sessions_router
from app.routes.students import router as students_router
from app.routes.engagement_ws import router as engagement_router
from app.routes.analytics import router as analytics_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting EngageIQ backend...")
    await create_tables()
    logger.info("Database tables ready.")
    import asyncio
    async def preload():
        from ml_inference.face_emotion.detector import get_face_detector
        from ml_inference.gaze_tracking.tracker import get_gaze_tracker
        from ml_inference.head_pose.estimator import get_head_pose_estimator
        from ml_inference.ces_engine.fusion import get_ces_engine
        get_face_detector(); get_gaze_tracker(); get_head_pose_estimator(); get_ces_engine()
        logger.info("ML models pre-loaded.")
    asyncio.create_task(preload())
    yield
    logger.info("Shutting down.")

app = FastAPI(title="EngageIQ API", description="AI-Driven Student Engagement Analysis System", version="2.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=[settings.FRONTEND_URL, "http://localhost:5173", "http://localhost:3000"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(auth_router, prefix="/api")
app.include_router(sessions_router, prefix="/api")
app.include_router(students_router, prefix="/api")
app.include_router(engagement_router)
app.include_router(analytics_router)

@app.get("/")
async def root(): return {"message": "EngageIQ API v2.0", "status": "running", "docs": "/docs"}

@app.get("/health")
async def health(): return {"status": "healthy", "version": "2.0.0"}
