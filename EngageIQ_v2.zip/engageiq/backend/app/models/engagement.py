import uuid
from datetime import datetime
from sqlalchemy import String, Float, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.database import Base


class EngagementEvent(Base):
    __tablename__ = "engagement_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id: Mapped[str] = mapped_column(String(36), ForeignKey("class_sessions.id"), index=True)
    student_id: Mapped[str] = mapped_column(String(36), ForeignKey("students.id"), index=True, nullable=True)
    student_label: Mapped[str] = mapped_column(String(50), nullable=True)  # e.g. "Student_1" if unregistered
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    # Composite Engagement Score
    ces: Mapped[float] = mapped_column(Float, nullable=True)

    # Face emotion
    emotion: Mapped[str] = mapped_column(String(30), nullable=True)
    emotion_confidence: Mapped[float] = mapped_column(Float, nullable=True)

    # Gaze
    gaze_direction: Mapped[str] = mapped_column(String(20), nullable=True)
    attention_score: Mapped[float] = mapped_column(Float, nullable=True)
    blink_rate: Mapped[float] = mapped_column(Float, nullable=True)

    # Head pose
    head_pitch: Mapped[float] = mapped_column(Float, nullable=True)
    head_yaw: Mapped[float] = mapped_column(Float, nullable=True)
    head_roll: Mapped[float] = mapped_column(Float, nullable=True)
    pose_label: Mapped[str] = mapped_column(String(30), nullable=True)  # attentive|looking_away|drowsy

    # Behavior
    behavior_signal: Mapped[str] = mapped_column(String(50), nullable=True)

    session = relationship("ClassSession", back_populates="engagement_events")
    student = relationship("Student", back_populates="engagement_events")
