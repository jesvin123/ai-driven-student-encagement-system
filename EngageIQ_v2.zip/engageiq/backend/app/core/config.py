from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    APP_NAME: str = "EngageIQ"
    APP_ENV: str = "development"
    SECRET_KEY: str = "dev-secret-key-change-in-production-32chars!!"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    DATABASE_URL: str = "sqlite+aiosqlite:///./engageiq.db"
    REDIS_URL: str = "redis://localhost:6379/0"

    GOOGLE_API_KEY: Optional[str] = None
    FRONTEND_URL: str = "http://localhost:5173"
    MODELS_DIR: str = "./ml_inference/models"
    MAX_UPLOAD_SIZE_MB: int = 10

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
