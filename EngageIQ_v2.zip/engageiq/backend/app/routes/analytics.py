from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.database import get_db
from app.models.engagement import EngagementEvent
from app.models.session import ClassSession
from app.models.user import User
from app.core.security import require_teacher

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

@router.get("/session/{session_id}/summary")
async def session_summary(session_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(require_teacher)):
    events_result = await db.execute(select(EngagementEvent).where(EngagementEvent.session_id == session_id).order_by(EngagementEvent.timestamp.asc()))
    events = events_result.scalars().all()
    if not events:
        return {"session_id": session_id, "message": "No data yet", "events": 0}
    ces_values = [e.ces for e in events if e.ces is not None]
    avg_ces = sum(ces_values) / len(ces_values) if ces_values else 0
    emotions = {}
    gaze = {}
    poses = {}
    for e in events:
        if e.emotion: emotions[e.emotion] = emotions.get(e.emotion, 0) + 1
        if e.gaze_direction: gaze[e.gaze_direction] = gaze.get(e.gaze_direction, 0) + 1
        if e.pose_label: poses[e.pose_label] = poses.get(e.pose_label, 0) + 1
    timeline = [{"t": e.timestamp.isoformat(), "ces": e.ces, "student": e.student_label} for e in events[::3] if e.ces is not None]
    return {"session_id": session_id, "total_events": len(events), "avg_ces": round(avg_ces, 1), "emotion_distribution": emotions, "gaze_distribution": gaze, "pose_distribution": poses, "ces_timeline": timeline}

@router.get("/overview")
async def analytics_overview(db: AsyncSession = Depends(get_db), current_user: User = Depends(require_teacher)):
    sessions_result = await db.execute(select(ClassSession).where(ClassSession.teacher_id == current_user.id).order_by(ClassSession.created_at.desc()).limit(20))
    sessions = sessions_result.scalars().all()
    return {"total_sessions": len(sessions), "sessions": [{"id": s.id, "subject": s.subject, "status": s.status, "avg_ces": s.avg_ces, "created_at": s.created_at.isoformat(), "start_time": s.start_time.isoformat() if s.start_time else None} for s in sessions]}
