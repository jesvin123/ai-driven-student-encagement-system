from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

from app.db.database import get_db
from app.models.student import Student
from app.models.user import User
from app.core.security import require_teacher

router = APIRouter(prefix="/students", tags=["students"])


class StudentCreate(BaseModel):
    name: str
    student_code: Optional[str] = None


class StudentResponse(BaseModel):
    id: str
    name: str
    student_code: Optional[str]
    baseline_ces: float
    created_at: datetime

    class Config:
        from_attributes = True


@router.post("", response_model=StudentResponse, status_code=201)
async def create_student(
    data: StudentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    student = Student(
        teacher_id=current_user.id,
        name=data.name,
        student_code=data.student_code,
    )
    db.add(student)
    await db.flush()
    await db.refresh(student)
    return student


@router.get("", response_model=list[StudentResponse])
async def list_students(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(Student)
        .where(Student.teacher_id == current_user.id)
        .order_by(Student.name.asc())
    )
    return result.scalars().all()


@router.delete("/{student_id}", status_code=204)
async def delete_student(
    student_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(Student).where(
            Student.id == student_id,
            Student.teacher_id == current_user.id,
        )
    )
    student = result.scalar_one_or_none()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    await db.delete(student)
