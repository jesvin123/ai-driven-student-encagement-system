from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

from app.db.database import get_db
from app.models.session import ClassSession
from app.models.engagement import EngagementEvent
from app.models.user import User
from app.core.security import require_teacher

router = APIRouter(prefix="/sessions", tags=["sessions"])


class SessionCreate(BaseModel):
    subject: str
    grade: Optional[str] = None
    description: Optional[str] = None


class SessionResponse(BaseModel):
    id: str
    subject: str
    grade: Optional[str]
    description: Optional[str]
    status: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    avg_ces: Optional[float]
    student_count: int
    created_at: datetime

    class Config:
        from_attributes = True


@router.post("", response_model=SessionResponse, status_code=201)
async def create_session(
    data: SessionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    session = ClassSession(
        teacher_id=current_user.id,
        subject=data.subject,
        grade=data.grade,
        description=data.description,
    )
    db.add(session)
    await db.flush()
    await db.refresh(session)
    return session


@router.get("", response_model=list[SessionResponse])
async def list_sessions(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(ClassSession)
        .where(ClassSession.teacher_id == current_user.id)
        .order_by(ClassSession.created_at.desc())
        .limit(50)
    )
    return result.scalars().all()


@router.get("/{session_id}", response_model=SessionResponse)
async def get_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(ClassSession).where(
            ClassSession.id == session_id,
            ClassSession.teacher_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@router.put("/{session_id}/start")
async def start_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(ClassSession).where(
            ClassSession.id == session_id,
            ClassSession.teacher_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.status == "active":
        raise HTTPException(status_code=400, detail="Session already active")

    session.status = "active"
    session.start_time = datetime.utcnow()
    return {"message": "Session started", "session_id": session_id, "status": "active"}


@router.put("/{session_id}/pause")
async def pause_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(ClassSession).where(
            ClassSession.id == session_id,
            ClassSession.teacher_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session.status = "paused"
    return {"message": "Session paused", "status": "paused"}


@router.put("/{session_id}/end")
async def end_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(ClassSession).where(
            ClassSession.id == session_id,
            ClassSession.teacher_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # Calculate avg CES
    ces_result = await db.execute(
        select(func.avg(EngagementEvent.ces)).where(
            EngagementEvent.session_id == session_id,
            EngagementEvent.ces != None,
        )
    )
    avg_ces = ces_result.scalar_one_or_none()

    session.status = "ended"
    session.end_time = datetime.utcnow()
    session.avg_ces = round(avg_ces, 1) if avg_ces else None

    return {"message": "Session ended", "status": "ended", "avg_ces": session.avg_ces}


@router.get("/{session_id}/report")
async def session_report(
    session_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    result = await db.execute(
        select(ClassSession).where(
            ClassSession.id == session_id,
            ClassSession.teacher_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # Aggregate engagement data
    events_result = await db.execute(
        select(EngagementEvent)
        .where(EngagementEvent.session_id == session_id)
        .order_by(EngagementEvent.timestamp.asc())
    )
    events = events_result.scalars().all()

    # Build time-series CES (sampled every 10 events)
    ces_timeline = [
        {"timestamp": e.timestamp.isoformat(), "ces": e.ces, "student": e.student_label}
        for e in events if e.ces is not None
    ][::5]  # every 5th event

    # Emotion distribution
    emotions = {}
    gaze_counts = {}
    pose_counts = {}
    for e in events:
        if e.emotion:
            emotions[e.emotion] = emotions.get(e.emotion, 0) + 1
        if e.gaze_direction:
            gaze_counts[e.gaze_direction] = gaze_counts.get(e.gaze_direction, 0) + 1
        if e.pose_label:
            pose_counts[e.pose_label] = pose_counts.get(e.pose_label, 0) + 1

    avg_ces = sum(e.ces for e in events if e.ces) / max(len([e for e in events if e.ces]), 1)

    return {
        "session": {
            "id": session.id,
            "subject": session.subject,
            "grade": session.grade,
            "status": session.status,
            "start_time": session.start_time,
            "end_time": session.end_time,
            "duration_minutes": (
                (session.end_time - session.start_time).seconds // 60
                if session.start_time and session.end_time else None
            ),
        },
        "summary": {
            "total_events": len(events),
            "avg_ces": round(avg_ces, 1),
            "emotion_distribution": emotions,
            "gaze_distribution": gaze_counts,
            "pose_distribution": pose_counts,
        },
        "ces_timeline": ces_timeline,
    }
