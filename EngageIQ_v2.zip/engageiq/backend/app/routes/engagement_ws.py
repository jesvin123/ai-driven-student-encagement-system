"""
WebSocket Routes for Real-Time Engagement
  WS /ws/teacher/{session_id}  - Teacher receives live CES updates
  WS /ws/student/{session_id}/{student_label} - Student sends frames, receives feedback
  GET /api/engagement/live/{session_id} - REST snapshot of current CES
"""
import asyncio
import json
import base64
import logging
from datetime import datetime
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.database import get_db, AsyncSessionLocal
from app.models.session import ClassSession
from app.models.engagement import EngagementEvent
from app.services.websocket_manager import get_connection_manager
from app.core.security import decode_token

from ml_inference.face_emotion.detector import get_face_detector
from ml_inference.gaze_tracking.tracker import get_gaze_tracker
from ml_inference.head_pose.estimator import get_head_pose_estimator
from ml_inference.ces_engine.fusion import get_ces_engine

logger = logging.getLogger(__name__)
router = APIRouter(tags=["engagement"])

# In-memory live CES state: session_id -> {student_label: latest_ces_data}
_live_state: dict = {}


def _update_live_state(session_id: str, student_label: str, ces_data: dict):
    if session_id not in _live_state:
        _live_state[session_id] = {}
    _live_state[session_id][student_label] = {
        **ces_data,
        "last_updated": datetime.utcnow().isoformat(),
    }


async def _process_frame(image_bytes: bytes, student_label: str, session_id: str) -> dict:
    """Run ML pipeline on a single frame and return engagement data."""
    loop = asyncio.get_event_loop()

    face_detector = get_face_detector()
    gaze_tracker = get_gaze_tracker()
    pose_estimator = get_head_pose_estimator()
    ces_engine = get_ces_engine()

    # Run all ML in thread pool to avoid blocking event loop
    face_result = await loop.run_in_executor(None, face_detector.detect, image_bytes)
    gaze_result = await loop.run_in_executor(None, gaze_tracker.analyze, image_bytes)
    pose_result = await loop.run_in_executor(None, pose_estimator.estimate, image_bytes)

    # Extract best face results (first face)
    emotion_score = None
    emotion = "neutral"
    gaze_score = None
    gaze_direction = "unknown"
    head_pose_score = None
    pose_label = "unknown"
    head_pitch = None
    head_yaw = None

    if face_result.get("faces"):
        f = face_result["faces"][0]
        emotion = f.get("emotion", "neutral")
        emotion_score = float(f.get("emotion_engagement_score", 65))

    if gaze_result.get("faces"):
        g = gaze_result["faces"][0]
        gaze_direction = g.get("gaze_direction", "unknown")
        gaze_score = float(g.get("attention_score", 65))

    if pose_result.get("faces"):
        p = pose_result["faces"][0]
        pose_label = p.get("pose_label", "unknown")
        head_pose_score = float(p.get("engagement_score", 65))
        head_pitch = p.get("pitch")
        head_yaw = p.get("yaw")

    # Compute CES
    ces_data = ces_engine.compute(
        student_id=student_label,
        emotion_score=emotion_score,
        gaze_score=gaze_score,
        head_pose_score=head_pose_score,
    )

    return {
        "student_label": student_label,
        "session_id": session_id,
        "ces": ces_data["ces"],
        "trend": ces_data["trend"],
        "alert_level": ces_data["alert_level"],
        "emotion": emotion,
        "gaze_direction": gaze_direction,
        "pose_label": pose_label,
        "head_pitch": head_pitch,
        "head_yaw": head_yaw,
        "attention_score": gaze_score,
        "component_scores": ces_data["component_scores"],
        "timestamp": datetime.utcnow().isoformat(),
    }


async def _save_engagement_event(session_id: str, data: dict):
    """Persist engagement data to DB (async, non-blocking)."""
    try:
        async with AsyncSessionLocal() as db:
            event = EngagementEvent(
                session_id=session_id,
                student_label=data.get("student_label"),
                ces=data.get("ces"),
                emotion=data.get("emotion"),
                gaze_direction=data.get("gaze_direction"),
                attention_score=data.get("attention_score"),
                head_pitch=data.get("head_pitch"),
                head_yaw=data.get("head_yaw"),
                pose_label=data.get("pose_label"),
                timestamp=datetime.utcnow(),
            )
            db.add(event)
            await db.commit()
    except Exception as e:
        logger.error("Failed to save engagement event: %s", e)


# ─────────────────────────────────────────────────────────────────────
# WebSocket: Student sends frames
# ─────────────────────────────────────────────────────────────────────
@router.websocket("/ws/student/{session_id}/{student_label}")
async def student_feed(
    websocket: WebSocket,
    session_id: str,
    student_label: str,
):
    manager = get_connection_manager()
    await manager.connect_student(websocket, session_id, student_label)
    ces_engine = get_ces_engine()

    frame_count = 0
    try:
        while True:
            # Receive frame as base64 text or binary bytes
            try:
                data = await asyncio.wait_for(websocket.receive(), timeout=30.0)
            except asyncio.TimeoutError:
                await websocket.send_text(json.dumps({"type": "ping"}))
                continue

            if data["type"] == "websocket.disconnect":
                break

            image_bytes = None
            if "bytes" in data and data["bytes"]:
                image_bytes = data["bytes"]
            elif "text" in data and data["text"]:
                try:
                    msg = json.loads(data["text"])
                    if msg.get("type") == "frame" and msg.get("data"):
                        image_bytes = base64.b64decode(msg["data"])
                    elif msg.get("type") == "ping":
                        await websocket.send_text(json.dumps({"type": "pong"}))
                        continue
                except Exception:
                    pass

            if image_bytes is None:
                continue

            # Process frame
            engagement_data = await _process_frame(image_bytes, student_label, session_id)
            frame_count += 1

            # Update live state
            _update_live_state(session_id, student_label, engagement_data)

            # Send result back to student
            await websocket.send_text(json.dumps({
                "type": "engagement_update",
                **engagement_data,
            }))

            # Broadcast to teachers watching this session
            await manager.broadcast_to_teachers(session_id, {
                "type": "student_update",
                **engagement_data,
            })

            # Save to DB every 5 frames (throttled)
            if frame_count % 5 == 0:
                asyncio.create_task(_save_engagement_event(session_id, engagement_data))

    except WebSocketDisconnect:
        logger.info("Student %s disconnected from session %s", student_label, session_id)
    except Exception as e:
        logger.error("Student WebSocket error: %s", e)
    finally:
        manager.disconnect_student(session_id, student_label)
        ces_engine.reset_student(student_label)


# ─────────────────────────────────────────────────────────────────────
# WebSocket: Teacher receives live dashboard updates
# ─────────────────────────────────────────────────────────────────────
@router.websocket("/ws/teacher/{session_id}")
async def teacher_dashboard_feed(
    websocket: WebSocket,
    session_id: str,
    token: str = None,
):
    manager = get_connection_manager()
    await manager.connect_teacher(websocket, session_id)

    try:
        # Send current state immediately on connect
        current = _live_state.get(session_id, {})
        await websocket.send_text(json.dumps({
            "type": "initial_state",
            "students": list(current.values()),
        }))

        # Keep alive — teacher WS is receive-only for class-wide commands
        while True:
            try:
                data = await asyncio.wait_for(websocket.receive(), timeout=30.0)
                if data["type"] == "websocket.disconnect":
                    break
                # Handle teacher commands (pause monitoring, send alert, etc.)
                if "text" in data:
                    try:
                        msg = json.loads(data["text"])
                        if msg.get("type") == "ping":
                            await websocket.send_text(json.dumps({"type": "pong"}))
                    except Exception:
                        pass
            except asyncio.TimeoutError:
                # Send class summary heartbeat
                ces_engine = get_ces_engine()
                students = manager.get_active_students(session_id)
                summary = ces_engine.get_class_summary(students)
                await websocket.send_text(json.dumps({
                    "type": "heartbeat",
                    "class_summary": summary,
                    "active_students": students,
                }))

    except WebSocketDisconnect:
        logger.info("Teacher disconnected from session %s", session_id)
    except Exception as e:
        logger.error("Teacher WebSocket error: %s", e)
    finally:
        manager.disconnect_teacher(websocket, session_id)


# ─────────────────────────────────────────────────────────────────────
# REST: Snapshot of current live engagement
# ─────────────────────────────────────────────────────────────────────
@router.get("/api/engagement/live/{session_id}")
async def get_live_engagement(session_id: str):
    current = _live_state.get(session_id, {})
    ces_engine = get_ces_engine()
    students = list(current.keys())
    summary = ces_engine.get_class_summary(students)
    return {
        "session_id": session_id,
        "students": list(current.values()),
        "class_summary": summary,
        "active_students": len(students),
    }
