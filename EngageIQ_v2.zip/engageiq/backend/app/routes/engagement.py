"""
Engagement Routes
- WebSocket /ws/session/{session_id}/teacher  — teacher dashboard live feed
- WebSocket /ws/session/{session_id}/student  — student sends frames, receives CES
- POST /api/engagement/frame                  — HTTP fallback for frame analysis
- GET  /api/engagement/live/{session_id}      — snapshot of current class CES
"""
import json
import base64
import logging
from datetime import datetime
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional

from app.db.database import get_db
from app.models.engagement import EngagementEvent
from app.models.session import ClassSession
from app.services.websocket_manager import manager
from app.core.security import get_current_user
from ml_inference.face_emotion.detector import get_face_detector
from ml_inference.gaze_tracking.tracker import get_gaze_tracker
from ml_inference.head_pose.estimator import get_head_pose_estimator
from ml_inference.ces_engine.engine import get_ces_engine

logger = logging.getLogger(__name__)

router = APIRouter(tags=["engagement"])
ws_router = APIRouter(tags=["websocket"])


# ──────────────────────────────────────────────
# CORE ANALYSIS FUNCTION (shared by WS + HTTP)
# ──────────────────────────────────────────────

async def analyze_frame(image_bytes: bytes, student_id: str, session_id: str) -> dict:
    """Run all ML modules on a single frame and return fused CES result."""
    face_detector = get_face_detector()
    gaze_tracker = get_gaze_tracker()
    head_pose_est = get_head_pose_estimator()
    ces_engine = get_ces_engine()

    # Run all detectors
    face_result = face_detector.detect(image_bytes)
    gaze_result = gaze_tracker.analyze(image_bytes)
    pose_result = head_pose_est.estimate(image_bytes)

    # Extract primary (first) face scores
    emotion_score = None
    emotion = "neutral"
    emotion_conf = 0.5
    gaze_score = None
    gaze_direction = "unknown"
    pose_score = None
    pose_label = "unknown"
    head_pitch = head_yaw = head_roll = None

    if face_result.get("faces"):
        f = face_result["faces"][0]
        emotion = f.get("emotion", "neutral")
        emotion_conf = f.get("confidence", 0.5)
        emotion_score = f.get("emotion_engagement_score", 65.0)

    if gaze_result.get("faces"):
        g = gaze_result["faces"][0]
        gaze_direction = g.get("gaze_direction", "unknown")
        gaze_score = g.get("attention_score", 65.0)

    if pose_result.get("faces"):
        p = pose_result["faces"][0]
        pose_label = p.get("pose_label", "unknown")
        pose_score = p.get("engagement_score", 65.0)
        head_pitch = p.get("pitch")
        head_yaw = p.get("yaw")
        head_roll = p.get("roll")

    # Fuse into CES
    ces_result = ces_engine.compute(
        student_id=student_id,
        emotion_score=emotion_score,
        gaze_score=gaze_score,
        head_pose_score=pose_score,
    )

    # Update connection manager
    manager.update_student_ces(session_id, student_id, ces_result["ces"])

    if ces_result.get("alert"):
        manager.add_alert(session_id, {
            "student_id": student_id,
            "timestamp": datetime.utcnow().isoformat(),
            **ces_result["alert"],
        })

    return {
        "student_id": student_id,
        "timestamp": datetime.utcnow().isoformat(),
        "ces": ces_result["ces"],
        "level": ces_result["level"],
        "alert": ces_result.get("alert"),
        "emotion": emotion,
        "emotion_confidence": emotion_conf,
        "gaze_direction": gaze_direction,
        "gaze_score": gaze_score,
        "pose_label": pose_label,
        "pose_score": pose_score,
        "head_pitch": head_pitch,
        "head_yaw": head_yaw,
        "component_scores": ces_result["component_scores"],
        "face_count": face_result.get("face_count", 0),
    }


async def save_event(result: dict, session_id: str, db: AsyncSession):
    """Persist engagement event to database."""
    event = EngagementEvent(
        session_id=session_id,
        student_label=result["student_id"],
        timestamp=datetime.utcnow(),
        ces=result["ces"],
        emotion=result["emotion"],
        emotion_confidence=result["emotion_confidence"],
        gaze_direction=result["gaze_direction"],
        attention_score=result["gaze_score"],
        head_pitch=result["head_pitch"],
        head_yaw=result["head_yaw"],
        pose_label=result["pose_label"],
    )
    db.add(event)
    try:
        await db.commit()
    except Exception as e:
        logger.error("Failed to save engagement event: %s", e)
        await db.rollback()


# ──────────────────────────────────────────────
# WEBSOCKET: TEACHER DASHBOARD
# ──────────────────────────────────────────────

@ws_router.websocket("/ws/session/{session_id}/teacher")
async def teacher_ws(websocket: WebSocket, session_id: str, token: str = Query(None)):
    """
    Teacher connects here to receive real-time class engagement updates.
    Sends current CES map every time any student's CES updates.
    Also sends periodic class summary every 5 seconds.
    """
    # Basic token validation (simplified — no DB lookup for WS handshake speed)
    if not token:
        await websocket.close(code=4001, reason="Authentication required")
        return

    await manager.connect_teacher(websocket, session_id)
    logger.info("Teacher WS connected for session %s", session_id)

    try:
        # Send initial state
        await websocket.send_json({
            "type": "connected",
            "session_id": session_id,
            "current_ces": manager.get_session_ces(session_id),
            "alerts": manager.get_alerts(session_id),
        })

        # Keep alive — receive pings from client
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
            elif msg.get("type") == "get_summary":
                ces_map = manager.get_session_ces(session_id)
                ces_engine = get_ces_engine()
                summary = ces_engine.get_class_summary(session_id, ces_map)
                await websocket.send_json({
                    "type": "class_summary",
                    "summary": summary,
                    "student_ces": ces_map,
                    "alerts": manager.get_alerts(session_id),
                })

    except WebSocketDisconnect:
        manager.disconnect_teacher(websocket, session_id)
        logger.info("Teacher WS disconnected from session %s", session_id)
    except Exception as e:
        logger.error("Teacher WS error: %s", e)
        manager.disconnect_teacher(websocket, session_id)


# ──────────────────────────────────────────────
# WEBSOCKET: STUDENT FRAME FEED
# ──────────────────────────────────────────────

@ws_router.websocket("/ws/session/{session_id}/student")
async def student_ws(
    websocket: WebSocket,
    session_id: str,
    student_id: str = Query("anonymous"),
    token: str = Query(None),
):
    """
    Student client sends webcam frames here (base64 JPEG).
    Server responds with real-time CES result.
    Also broadcasts to teacher dashboard.
    """
    await websocket.accept()
    logger.info("Student WS connected: %s -> session %s", student_id, session_id)
    frame_count = 0

    try:
        async for db in get_db():
            while True:
                data = await websocket.receive_text()
                msg = json.loads(data)

                if msg.get("type") == "frame":
                    frame_b64 = msg.get("data", "")
                    if not frame_b64:
                        continue

                    try:
                        image_bytes = base64.b64decode(frame_b64)
                    except Exception:
                        await websocket.send_json({"type": "error", "message": "Invalid frame data"})
                        continue

                    result = await analyze_frame(image_bytes, student_id, session_id)
                    frame_count += 1

                    # Send result back to student
                    await websocket.send_json({"type": "engagement_result", **result})

                    # Broadcast to teacher dashboard
                    await manager.broadcast_to_teachers(session_id, {
                        "type": "student_update",
                        **result,
                    })

                    # Persist every 5th frame to avoid DB overload
                    if frame_count % 5 == 0:
                        await save_event(result, session_id, db)

                elif msg.get("type") == "ping":
                    await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        logger.info("Student WS disconnected: %s", student_id)
    except Exception as e:
        logger.error("Student WS error: %s", e)


# ──────────────────────────────────────────────
# HTTP FALLBACK: Single Frame Analysis
# ──────────────────────────────────────────────

class FrameRequest(BaseModel):
    image_b64: str
    session_id: str
    student_id: str = "student_1"


@router.post("/engagement/analyze")
async def analyze_frame_http(
    data: FrameRequest,
    db: AsyncSession = Depends(get_db),
):
    """HTTP fallback for browsers that don't support WebSocket well."""
    try:
        image_bytes = base64.b64decode(data.image_b64)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid base64 image")

    result = await analyze_frame(image_bytes, data.student_id, data.session_id)

    # Broadcast to teachers
    await manager.broadcast_to_teachers(data.session_id, {
        "type": "student_update",
        **result,
    })

    await save_event(result, data.session_id, db)
    return result


# ──────────────────────────────────────────────
# HTTP: Live Snapshot
# ──────────────────────────────────────────────

@router.get("/engagement/live/{session_id}")
async def get_live_snapshot(
    session_id: str,
    current_user=Depends(get_current_user),
):
    """Get current CES snapshot for all students in a session."""
    ces_map = manager.get_session_ces(session_id)
    ces_engine = get_ces_engine()
    summary = ces_engine.get_class_summary(session_id, ces_map)
    return {
        "session_id": session_id,
        "timestamp": datetime.utcnow().isoformat(),
        "student_ces": ces_map,
        "summary": summary,
        "alerts": manager.get_alerts(session_id),
    }
