"""
Face Emotion Detection Module
Uses OpenCV + a lightweight CNN for emotion classification.
Falls back to rule-based if model not loaded.
"""
import numpy as np
import cv2
import logging
from typing import Optional
import os

logger = logging.getLogger(__name__)

# Emotion labels matching training data
EMOTIONS = ["angry", "disgust", "fear", "happy", "neutral", "sad", "surprise"]

# Engagement-weighted scores per emotion (contribution to CES)
EMOTION_ENGAGEMENT_WEIGHT = {
    "happy": 85,
    "surprise": 70,
    "neutral": 65,
    "fear": 45,
    "sad": 35,
    "angry": 30,
    "disgust": 25,
}


class FaceEmotionDetector:
    def __init__(self):
        self.face_cascade = None
        self.emotion_model = None
        self._loaded = False
        self._load_models()

    def _load_models(self):
        try:
            # Try OpenCV face detector
            cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            self.face_cascade = cv2.CascadeClassifier(cascade_path)

            # Try to load emotion model if available
            model_path = os.path.join(
                os.path.dirname(__file__), "models", "emotion_model.h5"
            )
            if os.path.exists(model_path):
                from tensorflow import keras
                self.emotion_model = keras.models.load_model(model_path, compile=False)
                logger.info("Emotion model loaded from %s", model_path)
            else:
                logger.warning("No emotion model found at %s — using mock predictions", model_path)

            self._loaded = True
        except Exception as e:
            logger.error("Failed to load face models: %s", e)
            self._loaded = False

    def detect(self, image_bytes: bytes) -> dict:
        """
        Detect faces and emotions from raw image bytes.
        Returns list of detected faces with emotion predictions.
        """
        try:
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                return {"faces": [], "error": "Could not decode image"}

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            if self.face_cascade is not None:
                faces_rect = self.face_cascade.detectMultiScale(
                    gray, scaleFactor=1.1, minNeighbors=5, minSize=(48, 48)
                )
            else:
                faces_rect = []

            faces = []
            for i, (x, y, w, h) in enumerate(faces_rect if len(faces_rect) > 0 else []):
                face_roi = gray[y:y+h, x:x+w]
                emotion, confidence, all_probs = self._classify_emotion(face_roi)
                engagement_score = EMOTION_ENGAGEMENT_WEIGHT.get(emotion, 50)

                faces.append({
                    "face_id": i,
                    "bbox": {"x": int(x), "y": int(y), "w": int(w), "h": int(h)},
                    "emotion": emotion,
                    "confidence": round(confidence, 3),
                    "all_emotions": all_probs,
                    "emotion_engagement_score": engagement_score,
                })

            # If no faces detected, return empty
            if not faces:
                return {"faces": [], "face_count": 0}

            return {"faces": faces, "face_count": len(faces)}

        except Exception as e:
            logger.error("Face detection error: %s", e)
            return {"faces": [], "error": str(e)}

    def _classify_emotion(self, face_gray: np.ndarray) -> tuple:
        """Classify emotion from grayscale face ROI."""
        try:
            if self.emotion_model is not None:
                face_resized = cv2.resize(face_gray, (48, 48))
                face_norm = face_resized.astype("float32") / 255.0
                face_input = face_norm.reshape(1, 48, 48, 1)
                probs = self.emotion_model.predict(face_input, verbose=0)[0]
                idx = int(np.argmax(probs))
                emotion = EMOTIONS[idx]
                confidence = float(probs[idx])
                all_probs = {EMOTIONS[i]: round(float(p), 3) for i, p in enumerate(probs)}
                return emotion, confidence, all_probs
            else:
                # Mock: return neutral as default when no model
                probs = np.random.dirichlet(np.ones(7) * 2)
                idx = int(np.argmax(probs))
                return EMOTIONS[idx], float(probs[idx]), {EMOTIONS[i]: round(float(p), 3) for i, p in enumerate(probs)}
        except Exception as e:
            logger.error("Emotion classification error: %s", e)
            return "neutral", 0.5, {e: 0.0 for e in EMOTIONS}


# Singleton instance
_detector: Optional[FaceEmotionDetector] = None


def get_face_detector() -> FaceEmotionDetector:
    global _detector
    if _detector is None:
        _detector = FaceEmotionDetector()
    return _detector
