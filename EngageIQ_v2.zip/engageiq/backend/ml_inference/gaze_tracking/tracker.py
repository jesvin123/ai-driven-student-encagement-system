"""
Gaze Tracking & Attention Module
Uses MediaPipe FaceMesh landmarks to estimate gaze direction.
Calculates attention score and blink rate.
"""
import numpy as np
import cv2
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Gaze direction labels
GAZE_LABELS = ["screen", "left", "right", "up", "down", "unknown"]

# MediaPipe eye landmark indices (left eye, right eye)
LEFT_EYE_IDX = [33, 160, 158, 133, 153, 144]
RIGHT_EYE_IDX = [263, 387, 385, 362, 380, 373]
LEFT_IRIS_IDX = [468, 469, 470, 471, 472]
RIGHT_IRIS_IDX = [473, 474, 475, 476, 477]


class GazeTracker:
    def __init__(self):
        self.face_mesh = None
        self._loaded = False
        self._blink_history = []
        self._load_models()

    def _load_models(self):
        try:
            import mediapipe as mp
            self.mp_face_mesh = mp.solutions.face_mesh
            self.face_mesh = self.mp_face_mesh.FaceMesh(
                static_image_mode=True,
                max_num_faces=10,
                refine_landmarks=True,  # enables iris landmarks
                min_detection_confidence=0.5,
            )
            self._loaded = True
            logger.info("MediaPipe FaceMesh loaded for gaze tracking")
        except ImportError:
            logger.warning("MediaPipe not installed — gaze tracking will use mock values")
        except Exception as e:
            logger.error("Failed to load gaze tracker: %s", e)

    def analyze(self, image_bytes: bytes) -> dict:
        """
        Analyze gaze from image bytes.
        Returns per-face gaze direction, attention score, blink rate.
        """
        try:
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                return {"faces": []}

            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            h, w = img.shape[:2]

            if not self._loaded or self.face_mesh is None:
                return self._mock_gaze()

            results = self.face_mesh.process(img_rgb)
            faces = []

            if results.multi_face_landmarks:
                for face_id, landmarks in enumerate(results.multi_face_landmarks):
                    lm = landmarks.landmark

                    gaze_dir = self._estimate_gaze_direction(lm, w, h)
                    ear = self._eye_aspect_ratio(lm)
                    attention_score = self._compute_attention(gaze_dir, ear)

                    faces.append({
                        "face_id": face_id,
                        "gaze_direction": gaze_dir,
                        "attention_score": round(attention_score, 1),
                        "eye_aspect_ratio": round(ear, 3),
                        "is_blinking": ear < 0.2,
                    })

            return {"faces": faces, "face_count": len(faces)}

        except Exception as e:
            logger.error("Gaze analysis error: %s", e)
            return self._mock_gaze()

    def _estimate_gaze_direction(self, landmarks, img_w: int, img_h: int) -> str:
        """Estimate gaze direction from iris position relative to eye corners."""
        try:
            # Get left iris center
            left_iris = landmarks[468]
            left_outer = landmarks[33]
            left_inner = landmarks[133]

            # Normalize iris position within eye
            eye_width = abs(left_inner.x - left_outer.x)
            if eye_width < 0.001:
                return "unknown"

            iris_relative_x = (left_iris.x - left_outer.x) / eye_width
            iris_relative_y = left_iris.y

            # Vertical (head pitch proxy)
            nose_tip = landmarks[4]
            forehead = landmarks[10]
            vertical_ratio = (nose_tip.y - forehead.y)

            if iris_relative_x < 0.35:
                return "right"  # looking to camera's right
            elif iris_relative_x > 0.65:
                return "left"   # looking to camera's left
            elif vertical_ratio < 0.12:
                return "up"
            elif vertical_ratio > 0.22:
                return "down"
            else:
                return "screen"
        except Exception:
            return "unknown"

    def _eye_aspect_ratio(self, landmarks) -> float:
        """Compute Eye Aspect Ratio (EAR) for blink detection."""
        try:
            # Left eye EAR
            p1 = np.array([landmarks[160].x, landmarks[160].y])
            p2 = np.array([landmarks[158].x, landmarks[158].y])
            p3 = np.array([landmarks[153].x, landmarks[153].y])
            p4 = np.array([landmarks[144].x, landmarks[144].y])
            p5 = np.array([landmarks[33].x, landmarks[33].y])
            p6 = np.array([landmarks[133].x, landmarks[133].y])

            ear = (np.linalg.norm(p1 - p2) + np.linalg.norm(p3 - p4)) / (2.0 * np.linalg.norm(p5 - p6))
            return float(ear)
        except Exception:
            return 0.3

    def _compute_attention(self, gaze_dir: str, ear: float) -> float:
        """Compute 0-100 attention score."""
        base = {
            "screen": 90, "up": 60, "down": 45,
            "left": 30, "right": 30, "unknown": 50
        }.get(gaze_dir, 50)

        # Penalize if blinking (eyes closed)
        if ear < 0.15:
            base *= 0.5
        elif ear < 0.2:
            base *= 0.8

        return min(100.0, max(0.0, base))

    def _mock_gaze(self) -> dict:
        """Return mock gaze data when MediaPipe not available."""
        import random
        gaze = random.choice(["screen", "screen", "screen", "left", "right", "down"])
        attention = {"screen": 88, "left": 35, "right": 30, "down": 45}.get(gaze, 60)
        return {
            "faces": [{
                "face_id": 0,
                "gaze_direction": gaze,
                "attention_score": float(attention + random.uniform(-5, 5)),
                "eye_aspect_ratio": 0.28,
                "is_blinking": False,
            }],
            "face_count": 1,
            "mock": True,
        }


_tracker: Optional[GazeTracker] = None


def get_gaze_tracker() -> GazeTracker:
    global _tracker
    if _tracker is None:
        _tracker = GazeTracker()
    return _tracker
