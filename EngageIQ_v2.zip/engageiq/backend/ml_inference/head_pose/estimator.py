"""
Head Pose Estimation Module
Uses MediaPipe FaceMesh + solvePnP to estimate 3D head orientation.
Classifies pose into: attentive | looking_away | drowsy | nodding
"""
import numpy as np
import cv2
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# 3D model points for head pose (canonical face model)
MODEL_POINTS_3D = np.array([
    (0.0, 0.0, 0.0),          # Nose tip
    (0.0, -330.0, -65.0),     # Chin
    (-225.0, 170.0, -135.0),  # Left eye corner
    (225.0, 170.0, -135.0),   # Right eye corner
    (-150.0, -150.0, -125.0), # Left mouth corner
    (150.0, -150.0, -125.0),  # Right mouth corner
], dtype=np.float64)

# Corresponding MediaPipe landmark indices
LANDMARK_INDICES = [4, 152, 263, 33, 287, 57]

POSE_LABELS = {
    "attentive": "Attentive",
    "looking_away": "Looking Away",
    "drowsy": "Drowsy",
    "nodding": "Nodding",
    "unknown": "Unknown",
}


class HeadPoseEstimator:
    def __init__(self):
        self.face_mesh = None
        self._loaded = False
        self._load_models()

    def _load_models(self):
        try:
            import mediapipe as mp
            self.mp_face_mesh = mp.solutions.face_mesh
            self.face_mesh = self.mp_face_mesh.FaceMesh(
                static_image_mode=True,
                max_num_faces=10,
                refine_landmarks=False,
                min_detection_confidence=0.5,
            )
            self._loaded = True
            logger.info("Head pose estimator (MediaPipe) loaded")
        except ImportError:
            logger.warning("MediaPipe not installed — head pose will use mock values")
        except Exception as e:
            logger.error("Failed to load head pose: %s", e)

    def estimate(self, image_bytes: bytes) -> dict:
        """Estimate head pose from image bytes."""
        try:
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                return {"faces": []}

            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            h, w = img.shape[:2]

            if not self._loaded or self.face_mesh is None:
                return self._mock_pose()

            results = self.face_mesh.process(img_rgb)
            faces = []

            if results.multi_face_landmarks:
                for face_id, landmarks in enumerate(results.multi_face_landmarks):
                    pitch, yaw, roll, pose_label = self._compute_pose(landmarks, w, h)
                    faces.append({
                        "face_id": face_id,
                        "pitch": round(pitch, 1),
                        "yaw": round(yaw, 1),
                        "roll": round(roll, 1),
                        "pose_label": pose_label,
                        "engagement_score": self._pose_to_score(pitch, yaw, pose_label),
                    })

            return {"faces": faces, "face_count": len(faces)}

        except Exception as e:
            logger.error("Head pose estimation error: %s", e)
            return self._mock_pose()

    def _compute_pose(self, landmarks, img_w: int, img_h: int) -> tuple:
        """Use solvePnP to get pitch, yaw, roll angles."""
        try:
            # Get 2D image points from landmarks
            image_points_2d = np.array([
                (landmarks.landmark[idx].x * img_w,
                 landmarks.landmark[idx].y * img_h)
                for idx in LANDMARK_INDICES
            ], dtype=np.float64)

            # Camera matrix (approximate for webcam)
            focal_length = img_w
            cx, cy = img_w / 2, img_h / 2
            camera_matrix = np.array([
                [focal_length, 0, cx],
                [0, focal_length, cy],
                [0, 0, 1]
            ], dtype=np.float64)

            dist_coeffs = np.zeros((4, 1))

            success, rot_vec, trans_vec = cv2.solvePnP(
                MODEL_POINTS_3D, image_points_2d,
                camera_matrix, dist_coeffs,
                flags=cv2.SOLVEPNP_ITERATIVE
            )

            if not success:
                return 0.0, 0.0, 0.0, "unknown"

            rot_mat, _ = cv2.Rodrigues(rot_vec)
            # Extract Euler angles (pitch=x-rot, yaw=y-rot, roll=z-rot)
            pitch = np.degrees(np.arctan2(rot_mat[2][1], rot_mat[2][2]))
            yaw = np.degrees(np.arctan2(-rot_mat[2][0], np.sqrt(rot_mat[2][1]**2 + rot_mat[2][2]**2)))
            roll = np.degrees(np.arctan2(rot_mat[1][0], rot_mat[0][0]))

            pose_label = self._classify_pose(pitch, yaw)
            return float(pitch), float(yaw), float(roll), pose_label

        except Exception as e:
            logger.error("solvePnP error: %s", e)
            return 0.0, 0.0, 0.0, "unknown"

    def _classify_pose(self, pitch: float, yaw: float) -> str:
        """Classify pose from Euler angles."""
        if abs(yaw) > 30:
            return "looking_away"
        elif pitch < -20:
            return "drowsy"
        elif 5 < pitch < 25 and abs(yaw) < 15:
            return "nodding"
        elif abs(pitch) <= 20 and abs(yaw) <= 30:
            return "attentive"
        return "unknown"

    def _pose_to_score(self, pitch: float, yaw: float, pose_label: str) -> float:
        """Convert pose to 0-100 engagement contribution score."""
        base = {
            "attentive": 85,
            "nodding": 95,
            "drowsy": 20,
            "looking_away": 15,
            "unknown": 50,
        }.get(pose_label, 50)
        # Fine-tune based on magnitude
        yaw_penalty = min(abs(yaw) / 90 * 30, 30)
        return max(0.0, min(100.0, base - yaw_penalty))

    def _mock_pose(self) -> dict:
        import random
        pitch = random.uniform(-5, 10)
        yaw = random.uniform(-15, 15)
        return {
            "faces": [{
                "face_id": 0,
                "pitch": round(pitch, 1),
                "yaw": round(yaw, 1),
                "roll": round(random.uniform(-5, 5), 1),
                "pose_label": "attentive",
                "engagement_score": 82.0,
            }],
            "face_count": 1,
            "mock": True,
        }


_estimator: Optional[HeadPoseEstimator] = None


def get_head_pose_estimator() -> HeadPoseEstimator:
    global _estimator
    if _estimator is None:
        _estimator = HeadPoseEstimator()
    return _estimator
