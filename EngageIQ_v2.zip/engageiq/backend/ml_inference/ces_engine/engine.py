"""
Composite Engagement Score (CES) Engine
Fuses signals from face emotion, gaze, head pose into a single 0-100 score.
Uses weighted late fusion with exponential moving average smoothing.
"""
import logging
from typing import Optional, Dict
from collections import defaultdict, deque

logger = logging.getLogger(__name__)

# Fusion weights (must sum to 1.0)
WEIGHTS = {
    "emotion":   0.30,
    "gaze":      0.30,
    "head_pose": 0.25,
    "behavior":  0.15,
}

# Smoothing factor (higher = more responsive, lower = smoother)
EMA_ALPHA = 0.35

# Alert threshold
ALERT_THRESHOLD = 40.0
ALERT_DURATION_SECONDS = 10


class CESEngine:
    """
    Maintains per-student EMA state and computes composite engagement scores.
    """
    def __init__(self):
        # student_id -> deque of recent CES values
        self._ema_state: Dict[str, float] = {}
        self._history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=300))
        self._alert_counter: Dict[str, int] = defaultdict(int)

    def compute(
        self,
        student_id: str,
        emotion_score: Optional[float] = None,
        gaze_score: Optional[float] = None,
        head_pose_score: Optional[float] = None,
        behavior_score: Optional[float] = None,
    ) -> dict:
        """
        Compute CES for a student from available modality scores.
        Missing modalities are replaced with their neutral baseline (65).
        """
        scores = {
            "emotion":   emotion_score   if emotion_score   is not None else 65.0,
            "gaze":      gaze_score      if gaze_score      is not None else 65.0,
            "head_pose": head_pose_score if head_pose_score is not None else 65.0,
            "behavior":  behavior_score  if behavior_score  is not None else 65.0,
        }

        # Weighted sum
        raw_ces = sum(scores[k] * WEIGHTS[k] for k in WEIGHTS)

        # EMA smoothing
        if student_id in self._ema_state:
            smoothed = EMA_ALPHA * raw_ces + (1 - EMA_ALPHA) * self._ema_state[student_id]
        else:
            smoothed = raw_ces

        self._ema_state[student_id] = smoothed
        self._history[student_id].append(smoothed)

        # Alert tracking
        alert = self._check_alert(student_id, smoothed)

        # Engagement level label
        level = self._score_to_level(smoothed)

        return {
            "student_id": student_id,
            "ces": round(smoothed, 1),
            "raw_ces": round(raw_ces, 1),
            "level": level,
            "component_scores": {k: round(v, 1) for k, v in scores.items()},
            "alert": alert,
        }

    def _score_to_level(self, ces: float) -> str:
        if ces >= 80:
            return "highly_engaged"
        elif ces >= 60:
            return "engaged"
        elif ces >= 40:
            return "partially_engaged"
        else:
            return "disengaged"

    def _check_alert(self, student_id: str, ces: float) -> Optional[dict]:
        if ces < ALERT_THRESHOLD:
            self._alert_counter[student_id] += 1
            if self._alert_counter[student_id] >= ALERT_DURATION_SECONDS:
                return {
                    "type": "low_engagement",
                    "message": f"Student has been disengaged for {self._alert_counter[student_id]}s",
                    "ces": round(ces, 1),
                }
        else:
            self._alert_counter[student_id] = 0
        return None

    def get_class_summary(self, session_id: str, student_ces_map: dict) -> dict:
        """Compute class-wide engagement statistics."""
        if not student_ces_map:
            return {"avg_ces": 0, "level_distribution": {}, "alerts": []}

        values = list(student_ces_map.values())
        avg = sum(values) / len(values)

        levels = {"highly_engaged": 0, "engaged": 0, "partially_engaged": 0, "disengaged": 0}
        alerts = []
        for sid, ces in student_ces_map.items():
            lv = self._score_to_level(ces)
            levels[lv] = levels.get(lv, 0) + 1
            if ces < ALERT_THRESHOLD:
                alerts.append({"student_id": sid, "ces": ces})

        return {
            "avg_ces": round(avg, 1),
            "class_level": self._score_to_level(avg),
            "level_distribution": levels,
            "disengaged_count": levels["disengaged"],
            "alerts": alerts,
        }

    def reset_student(self, student_id: str):
        self._ema_state.pop(student_id, None)
        self._history.pop(student_id, None)
        self._alert_counter.pop(student_id, None)


# Singleton per session is managed by the WebSocket connection manager
_engine: Optional[CESEngine] = None


def get_ces_engine() -> CESEngine:
    global _engine
    if _engine is None:
        _engine = CESEngine()
    return _engine
