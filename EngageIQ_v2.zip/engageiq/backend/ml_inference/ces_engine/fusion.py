"""
Composite Engagement Score (CES) Engine
Fuses signals from all modalities into a single 0-100 engagement score.
Weights: Emotion(30%) + Gaze/Attention(25%) + Head Pose(20%) + Voice(15%) + Behavior(10%)
"""
import logging
from typing import Optional
from collections import deque
import time

logger = logging.getLogger(__name__)

# Fusion weights (must sum to 1.0)
WEIGHTS = {
    "emotion": 0.30,
    "gaze": 0.25,
    "head_pose": 0.20,
    "voice": 0.15,
    "behavior": 0.10,
}

# Behavior signal scores
BEHAVIOR_SCORES = {
    "hand_raise": 95,
    "note_taking": 90,
    "leaning_forward": 85,
    "neutral": 65,
    "yawning": 20,
    "phone_usage": 10,
    "head_in_hands": 15,
    "unknown": 60,
}

# EMA smoothing factor (0 = no smoothing, 1 = full smoothing)
EMA_ALPHA = 0.3


class StudentCESTracker:
    """Per-student CES tracker with temporal smoothing."""

    def __init__(self, student_id: str):
        self.student_id = student_id
        self.current_ces = 65.0  # default starting score
        self.history = deque(maxlen=60)  # last 60 readings
        self.last_update = time.time()

    def update(self, new_ces: float) -> float:
        """Apply EMA smoothing and return updated CES."""
        smoothed = EMA_ALPHA * new_ces + (1 - EMA_ALPHA) * self.current_ces
        self.current_ces = round(smoothed, 1)
        self.history.append({
            "ces": self.current_ces,
            "timestamp": time.time(),
        })
        self.last_update = time.time()
        return self.current_ces

    def get_trend(self) -> str:
        """Compute trend: rising | falling | stable."""
        if len(self.history) < 5:
            return "stable"
        recent = [h["ces"] for h in list(self.history)[-5:]]
        delta = recent[-1] - recent[0]
        if delta > 5:
            return "rising"
        elif delta < -5:
            return "falling"
        return "stable"


class CESFusionEngine:
    """
    Fuses multi-modal signals into Composite Engagement Score.
    Maintains per-student trackers for temporal smoothing.
    """

    def __init__(self):
        self._student_trackers: dict[str, StudentCESTracker] = {}

    def _get_tracker(self, student_id: str) -> StudentCESTracker:
        if student_id not in self._student_trackers:
            self._student_trackers[student_id] = StudentCESTracker(student_id)
        return self._student_trackers[student_id]

    def compute(
        self,
        student_id: str,
        emotion_score: Optional[float] = None,
        gaze_score: Optional[float] = None,
        head_pose_score: Optional[float] = None,
        voice_score: Optional[float] = None,
        behavior_signal: Optional[str] = None,
    ) -> dict:
        """
        Compute CES from available modality scores.
        Missing modalities are redistributed proportionally.
        Returns dict with ces, trend, alert_level.
        """
        scores = {}
        available_weight = 0.0

        if emotion_score is not None:
            scores["emotion"] = max(0.0, min(100.0, emotion_score))
            available_weight += WEIGHTS["emotion"]

        if gaze_score is not None:
            scores["gaze"] = max(0.0, min(100.0, gaze_score))
            available_weight += WEIGHTS["gaze"]

        if head_pose_score is not None:
            scores["head_pose"] = max(0.0, min(100.0, head_pose_score))
            available_weight += WEIGHTS["head_pose"]

        if voice_score is not None:
            scores["voice"] = max(0.0, min(100.0, voice_score))
            available_weight += WEIGHTS["voice"]

        if behavior_signal is not None:
            scores["behavior"] = float(BEHAVIOR_SCORES.get(behavior_signal, 60))
            available_weight += WEIGHTS["behavior"]

        # Fallback if nothing available
        if not scores:
            raw_ces = 60.0
        elif available_weight < 0.01:
            raw_ces = 60.0
        else:
            # Weighted sum normalized to available weight
            raw_ces = sum(
                scores[k] * WEIGHTS[k] for k in scores
            ) / available_weight

        tracker = self._get_tracker(student_id)
        smoothed_ces = tracker.update(raw_ces)
        trend = tracker.get_trend()
        alert_level = self._get_alert_level(smoothed_ces)

        return {
            "student_id": student_id,
            "ces": smoothed_ces,
            "raw_ces": round(raw_ces, 1),
            "trend": trend,
            "alert_level": alert_level,
            "component_scores": {k: round(v, 1) for k, v in scores.items()},
            "modalities_used": list(scores.keys()),
        }

    def _get_alert_level(self, ces: float) -> str:
        """Classify engagement level for alerting."""
        if ces >= 70:
            return "good"
        elif ces >= 50:
            return "warning"
        elif ces >= 30:
            return "low"
        else:
            return "critical"

    def reset_student(self, student_id: str):
        """Reset tracker for a student (e.g. new session)."""
        if student_id in self._student_trackers:
            del self._student_trackers[student_id]

    def get_class_summary(self, student_ids: list) -> dict:
        """Compute class-level aggregated CES."""
        scores = []
        for sid in student_ids:
            if sid in self._student_trackers:
                scores.append(self._student_trackers[sid].current_ces)

        if not scores:
            return {"avg_ces": 0, "min_ces": 0, "max_ces": 0, "disengaged_count": 0}

        return {
            "avg_ces": round(sum(scores) / len(scores), 1),
            "min_ces": round(min(scores), 1),
            "max_ces": round(max(scores), 1),
            "disengaged_count": sum(1 for s in scores if s < 40),
            "student_count": len(scores),
        }


# Global engine instance (shared across WebSocket connections)
_engine: Optional[CESFusionEngine] = None


def get_ces_engine() -> CESFusionEngine:
    global _engine
    if _engine is None:
        _engine = CESFusionEngine()
    return _engine
