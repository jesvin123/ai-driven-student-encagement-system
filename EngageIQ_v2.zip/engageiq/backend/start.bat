@echo off
echo ============================================
echo  EngageIQ Backend - Windows Startup Script
echo ============================================

cd /d "%~dp0"

REM Check if virtual environment exists
if not exist "venv\Scripts\activate.bat" (
    echo [INFO] Creating virtual environment...
    python -m venv venv
)

echo [INFO] Activating virtual environment...
call venv\Scripts\activate.bat

echo [INFO] Installing/updating dependencies...
pip install -r requirements.txt --quiet

REM Copy .env if not exists
if not exist ".env" (
    echo [INFO] Creating .env from template...
    copy .env.example .env
    echo [WARN] Please edit .env and add your GOOGLE_API_KEY
)

echo [INFO] Starting EngageIQ backend on http://localhost:8000
echo [INFO] API docs: http://localhost:8000/docs
echo.
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

pause
