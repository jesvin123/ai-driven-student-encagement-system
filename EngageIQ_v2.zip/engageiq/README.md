# EngageIQ — AI-Driven Student Engagement Analysis System v2.0

## Quick Start (Windows)

### Prerequisites
- Python 3.11+  (https://python.org)
- Node.js 18+   (https://nodejs.org)

### One-Click Start
```
Double-click: START_HERE.bat
```

### Manual Start

**Backend:**
```cmd
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
# Edit .env and add your GOOGLE_API_KEY (optional)
python -m uvicorn app.main:app --reload --port 8000
```

**Frontend (new terminal):**
```cmd
cd frontend
npm install
npm run dev
```

Open: http://localhost:5173

---

## URLs
| Service       | URL                          |
|--------------|------------------------------|
| Frontend     | http://localhost:5173        |
| Backend API  | http://localhost:8000        |
| API Docs     | http://localhost:8000/docs   |

---

## How to Use

### Teacher Flow
1. Register/login at http://localhost:5173/login
2. Click **New Session** → enter subject & grade
3. Click **Start** → click **Monitor** to open live dashboard
4. Share the **Student Join Link** with your students
5. Watch real-time engagement scores per student
6. Click any student tile to see detailed breakdown
7. Click **End Session** → view full analytics report

### Student Flow
1. Open the link shared by the teacher:
   `http://localhost:5173/student/{session-id}/{your-name}`
2. Click **Start Camera** and allow webcam access
3. Your engagement is analyzed in real-time
4. Your teacher can see your CES score on their dashboard

---

## Architecture
```
frontend/          React + Vite + Tailwind + Zustand
backend/
  app/
    routes/        auth, sessions, students, engagement WebSocket, analytics
    models/        User, ClassSession, Student, EngagementEvent (SQLAlchemy)
    core/          JWT security, config
    db/            Async SQLAlchemy + SQLite (upgradeable to PostgreSQL)
  ml_inference/
    face_emotion/  OpenCV + CNN emotion detection
    gaze_tracking/ MediaPipe FaceMesh + iris gaze estimation
    head_pose/     solvePnP 3D head pose (pitch/yaw/roll)
    ces_engine/    Composite Engagement Score fusion + EMA smoothing
```

## ML Modules
| Module | Technology | Output |
|--------|-----------|--------|
| Face Emotion | OpenCV + CNN | 7 emotions + score |
| Gaze Tracking | MediaPipe FaceMesh | Direction + attention 0-100 |
| Head Pose | solvePnP | Pitch/Yaw/Roll + pose label |
| CES Engine | Weighted fusion + EMA | Composite score 0-100 |

## Upgrading to Production
1. Replace SQLite with PostgreSQL: update `DATABASE_URL` in `.env`
2. Run with Docker: `docker-compose up --build`
3. Add TimescaleDB for high-frequency time-series
4. Replace mock ML models with your trained `.h5` weights in `ml_inference/*/models/`
