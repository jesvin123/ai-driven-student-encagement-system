/**
 * Engagement score utilities
 */

export function cesLevel(score) {
  if (score >= 80) return 'highly_engaged'
  if (score >= 60) return 'engaged'
  if (score >= 40) return 'partially_engaged'
  return 'disengaged'
}

export function cesLabel(score) {
  const map = {
    highly_engaged:   'Highly Engaged',
    engaged:          'Engaged',
    partially_engaged:'Partially Engaged',
    disengaged:       'Disengaged',
  }
  return map[cesLevel(score)] || 'Unknown'
}

export function cesColor(score) {
  if (score >= 80) return '#10b981'
  if (score >= 60) return '#3b82f6'
  if (score >= 40) return '#f59e0b'
  return '#ef4444'
}

export function cesBgClass(score) {
  if (score >= 80) return 'ces-bg-high'
  if (score >= 60) return 'badge-blue'
  if (score >= 40) return 'ces-bg-mid'
  return 'ces-bg-low'
}

export function emotionEmoji(emotion) {
  const map = {
    happy: '😊', sad: '😢', angry: '😠', fear: '😨',
    surprise: '😲', disgust: '🤢', neutral: '😐',
    confused: '😕', focused: '🎯',
  }
  return map[emotion] || '😐'
}

export function gazeLabel(dir) {
  const map = {
    screen: 'On Screen', left: 'Looking Left', right: 'Looking Right',
    up: 'Looking Up', down: 'Looking Down', unknown: 'Unknown',
  }
  return map[dir] || dir
}

export function poseLabel(label) {
  const map = {
    attentive: 'Attentive', looking_away: 'Looking Away',
    drowsy: 'Drowsy', nodding: 'Nodding', unknown: 'Unknown',
  }
  return map[label] || label
}
