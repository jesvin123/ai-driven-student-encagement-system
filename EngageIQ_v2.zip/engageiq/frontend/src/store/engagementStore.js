import { create } from 'zustand'
const useEngagementStore = create((set) => ({
  students: {},           // studentLabel -> latest engagement data
  classSummary: null,
  alerts: [],
  wsConnected: false,
  updateStudent: (label, data) => set((state) => ({
    students: { ...state.students, [label]: { ...data, label } }
  })),
  setStudents: (students) => set({ students }),
  setClassSummary: (summary) => set({ classSummary: summary }),
  addAlert: (alert) => set((state) => ({ alerts: [alert, ...state.alerts].slice(0, 20) })),
  clearAlerts: () => set({ alerts: [] }),
  setWsConnected: (v) => set({ wsConnected: v }),
  reset: () => set({ students: {}, classSummary: null, alerts: [], wsConnected: false }),
}))
export default useEngagementStore
