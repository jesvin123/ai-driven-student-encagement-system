import { create } from 'zustand'
const useSessionStore = create((set) => ({
  sessions: [],
  activeSession: null,
  setSessions: (sessions) => set({ sessions }),
  setActiveSession: (session) => set({ activeSession: session }),
  updateSession: (id, updates) => set((state) => ({
    sessions: state.sessions.map(s => s.id === id ? { ...s, ...updates } : s),
    activeSession: state.activeSession?.id === id ? { ...state.activeSession, ...updates } : state.activeSession,
  })),
}))
export default useSessionStore
