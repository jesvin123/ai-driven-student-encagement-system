/**
 * WebSocket service for real-time engagement streaming
 */

const WS_BASE = `ws://${window.location.hostname}:8000`

export class TeacherWebSocket {
  constructor(sessionId, onMessage) {
    this.sessionId = sessionId
    this.onMessage = onMessage
    this.ws = null
    this.reconnectTimer = null
    this.alive = true
  }

  connect() {
    const token = localStorage.getItem('access_token')
    const url = `${WS_BASE}/ws/teacher/${this.sessionId}?token=${token}`
    this.ws = new WebSocket(url)

    this.ws.onopen = () => {
      console.log('[WS Teacher] Connected to session', this.sessionId)
      this.onMessage({ type: 'connected' })
    }
    this.ws.onmessage = (e) => {
      try { this.onMessage(JSON.parse(e.data)) } catch {}
    }
    this.ws.onerror = (e) => console.error('[WS Teacher] Error', e)
    this.ws.onclose = () => {
      if (this.alive) {
        console.log('[WS Teacher] Disconnected — reconnecting in 3s')
        this.reconnectTimer = setTimeout(() => this.connect(), 3000)
      }
    }
  }

  ping() {
    if (this.ws?.readyState === WebSocket.OPEN)
      this.ws.send(JSON.stringify({ type: 'ping' }))
  }

  disconnect() {
    this.alive = false
    clearTimeout(this.reconnectTimer)
    this.ws?.close()
  }
}

export class StudentWebSocket {
  constructor(sessionId, studentLabel, onResult) {
    this.sessionId = sessionId
    this.studentLabel = studentLabel
    this.onResult = onResult
    this.ws = null
    this.alive = true
    this.frameInterval = null
  }

  connect(videoElement) {
    const url = `${WS_BASE}/ws/student/${this.sessionId}/${this.studentLabel}`
    this.ws = new WebSocket(url)
    this.ws.onopen = () => {
      console.log('[WS Student] Connected')
      if (videoElement) this._startCapture(videoElement)
    }
    this.ws.onmessage = (e) => {
      try { this.onResult(JSON.parse(e.data)) } catch {}
    }
    this.ws.onerror = (e) => console.error('[WS Student] Error', e)
    this.ws.onclose = () => {
      this._stopCapture()
      if (this.alive) setTimeout(() => this.connect(videoElement), 3000)
    }
  }

  _startCapture(videoEl) {
    const canvas = document.createElement('canvas')
    canvas.width = 320; canvas.height = 240
    const ctx = canvas.getContext('2d')

    this.frameInterval = setInterval(() => {
      if (this.ws?.readyState !== WebSocket.OPEN) return
      try {
        ctx.drawImage(videoEl, 0, 0, 320, 240)
        canvas.toBlob((blob) => {
          if (!blob) return
          blob.arrayBuffer().then((buf) => {
            if (this.ws?.readyState === WebSocket.OPEN)
              this.ws.send(buf)
          })
        }, 'image/jpeg', 0.7)
      } catch {}
    }, 500) // 2 FPS — enough for engagement analysis
  }

  _stopCapture() {
    clearInterval(this.frameInterval)
    this.frameInterval = null
  }

  disconnect() {
    this.alive = false
    this._stopCapture()
    this.ws?.close()
  }
}
