import axios from 'axios'

const api = axios.create({ baseURL: '/api', timeout: 15000 })

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (r) => r,
  async (error) => {
    if (error.response?.status === 401) {
      const refresh = localStorage.getItem('refresh_token')
      if (refresh) {
        try {
          const res = await axios.post('/api/auth/refresh', { refresh_token: refresh })
          localStorage.setItem('access_token', res.data.access_token)
          localStorage.setItem('refresh_token', res.data.refresh_token)
          error.config.headers.Authorization = `Bearer ${res.data.access_token}`
          return api.request(error.config)
        } catch { }
      }
      localStorage.clear()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  me: () => api.get('/auth/me'),
}

export const sessionAPI = {
  list: () => api.get('/sessions'),
  create: (data) => api.post('/sessions', data),
  get: (id) => api.get(`/sessions/${id}`),
  start: (id) => api.put(`/sessions/${id}/start`),
  pause: (id) => api.put(`/sessions/${id}/pause`),
  end: (id) => api.put(`/sessions/${id}/end`),
  report: (id) => api.get(`/sessions/${id}/report`),
}

export const studentAPI = {
  list: () => api.get('/students'),
  create: (data) => api.post('/students', data),
  delete: (id) => api.delete(`/students/${id}`),
}

export const analyticsAPI = {
  overview: () => api.get('/analytics/overview'),
  sessionSummary: (id) => api.get(`/analytics/session/${id}/summary`),
  live: (sessionId) => api.get(`/engagement/live/${sessionId}`),
}

export default api
