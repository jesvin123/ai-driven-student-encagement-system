import { cesColor, cesLabel } from '../../utils/engagement'

/**
 * Circular CES gauge with animated arc.
 */
export default function CESGauge({ score = 0, size = 120, showLabel = true }) {
  const radius = (size - 16) / 2
  const circumference = 2 * Math.PI * radius
  const clampedScore = Math.min(100, Math.max(0, score))
  const offset = circumference - (clampedScore / 100) * circumference
  const color = cesColor(clampedScore)

  return (
    <div className="flex flex-col items-center gap-1">
      <div style={{ width: size, height: size }} className="relative">
        <svg width={size} height={size} className="-rotate-90">
          {/* Background track */}
          <circle
            cx={size / 2} cy={size / 2} r={radius}
            fill="none" stroke="#1f2937" strokeWidth="8"
          />
          {/* Score arc */}
          <circle
            cx={size / 2} cy={size / 2} r={radius}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.6s ease, stroke 0.4s ease' }}
          />
        </svg>
        {/* Score text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span
            className="font-bold leading-none"
            style={{ fontSize: size * 0.22, color }}
          >
            {Math.round(clampedScore)}
          </span>
          <span className="text-gray-500" style={{ fontSize: size * 0.1 }}>CES</span>
        </div>
      </div>
      {showLabel && (
        <span className="text-xs text-gray-400 font-medium">{cesLabel(clampedScore)}</span>
      )}
    </div>
  )
}
