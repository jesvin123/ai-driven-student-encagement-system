import { AlertTriangle, X, Bell } from 'lucide-react'
import { getCESColor } from '../common/CESBadge'
import clsx from 'clsx'

export default function AlertBanner({ alerts, onDismiss }) {
  if (!alerts?.length) return null
  return (
    <div className="flex flex-col gap-2 mb-4">
      {alerts.slice(0, 3).map((alert, i) => (
        <div key={i} className={clsx(
          'flex items-start gap-3 px-4 py-3 rounded-xl border text-sm animate-slide-up',
          alert.level === 'critical'
            ? 'bg-red-500/10 border-red-500/40 text-red-300'
            : 'bg-amber-500/10 border-amber-500/40 text-amber-300'
        )}>
          <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="font-semibold">{alert.title}</p>
            <p className="opacity-75 text-xs mt-0.5">{alert.message}</p>
          </div>
          <button onClick={() => onDismiss?.(i)} className="opacity-50 hover:opacity-100 transition-opacity">
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  )
}
