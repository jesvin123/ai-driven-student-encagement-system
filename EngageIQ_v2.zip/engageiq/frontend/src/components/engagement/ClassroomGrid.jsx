import StudentTile from './StudentTile'
import { Users } from 'lucide-react'

export default function ClassroomGrid({ students, onStudentClick }) {
  const list = Object.values(students)
  if (!list.length) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500 gap-3">
        <Users className="w-12 h-12 opacity-30" />
        <p className="text-sm">Waiting for students to connect...</p>
        <p className="text-xs opacity-60">Students join via the Student View link</p>
      </div>
    )
  }
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
      {list.map((s) => (
        <StudentTile key={s.label} student={s} onClick={() => onStudentClick?.(s)} />
      ))}
    </div>
  )
}
