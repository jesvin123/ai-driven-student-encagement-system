import CESGauge from '../common/CESGauge'
import { getCESColor } from '../common/CESBadge'
import { TrendingUp, TrendingDown, Minus, Eye, Brain, Activity } from 'lucide-react'
import clsx from 'clsx'

const EMOTION_EMOJI = {
  happy:'😊', sad:'😢', angry:'😠', fear:'😨',
  surprise:'😲', disgust:'🤢', neutral:'😐', unknown:'❓'
}

const GAZE_ICON = { screen:'🎯', left:'👈', right:'👉', up:'👆', down:'👇', unknown:'❓' }

function TrendIcon({ trend }) {
  if (trend === 'rising') return <TrendingUp className="w-3 h-3 text-emerald-400" />
  if (trend === 'falling') return <TrendingDown className="w-3 h-3 text-red-400" />
  return <Minus className="w-3 h-3 text-slate-500" />
}

export default function StudentTile({ student, onClick }) {
  const {
    label = 'Student', ces = 0, emotion = 'neutral',
    gaze_direction = 'unknown', pose_label = 'unknown',
    trend = 'stable', alert_level = 'good', attention_score
  } = student || {}

  const color = getCESColor(ces)
  const isAlert = alert_level === 'critical' || alert_level === 'low'

  return (
    <button onClick={onClick}
      className={clsx(
        'relative flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all duration-300 cursor-pointer text-left w-full',
        'hover:scale-[1.02] hover:shadow-lg active:scale-[0.98]',
        isAlert
          ? 'bg-red-500/5 border-red-500/40 shadow-red-500/10 shadow-md'
          : 'bg-slate-900 border-slate-700/60 hover:border-slate-600'
      )}
      style={isAlert ? { boxShadow: `0 0 16px ${color}22` } : {}}>

      {/* Alert pulse */}
      {isAlert && (
        <span className="absolute top-2 right-2 flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-400" />
        </span>
      )}

      {/* Gauge */}
      <CESGauge ces={ces} size={72} />

      {/* Name + trend */}
      <div className="flex items-center gap-1 w-full justify-center">
        <span className="text-xs font-semibold text-white truncate max-w-[80px]">{label}</span>
        <TrendIcon trend={trend} />
      </div>

      {/* Signals row */}
      <div className="flex items-center justify-between w-full px-1 text-xs text-slate-400">
        <span title="Emotion">{EMOTION_EMOJI[emotion] || '😐'}</span>
        <span title="Gaze">{GAZE_ICON[gaze_direction] || '❓'}</span>
        <span title={`Pose: ${pose_label}`}>
          {pose_label === 'attentive' ? '✅' : pose_label === 'drowsy' ? '😴' : pose_label === 'looking_away' ? '🔄' : '❓'}
        </span>
      </div>

      {/* Attention bar */}
      {attention_score != null && (
        <div className="w-full">
          <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full rounded-full transition-all duration-500"
              style={{ width: `${attention_score}%`, background: color }} />
          </div>
        </div>
      )}
    </button>
  )
}
