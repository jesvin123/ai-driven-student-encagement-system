import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'

const GAZE_COLORS = { screen: '#10b981', up: '#6366f1', down: '#f59e0b', left: '#f87171', right: '#f87171', unknown: '#475569' }

export default function GazeBarChart({ data = {}, height = 160 }) {
  const chartData = Object.entries(data).map(([name, value]) => ({ name, value }))
  if (!chartData.length) return <div className="flex items-center justify-center h-20 text-slate-500 text-sm">No data yet</div>
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={chartData} margin={{ top: 4, right: 8, left: -24, bottom: 0 }}>
        <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 10 }} tickLine={false} axisLine={false} />
        <YAxis tick={{ fill: '#64748b', fontSize: 10 }} tickLine={false} axisLine={false} />
        <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12, fontSize: 12 }} />
        <Bar dataKey="value" radius={[4, 4, 0, 0]}>
          {chartData.map((entry) => <Cell key={entry.name} fill={GAZE_COLORS[entry.name] || '#6366f1'} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
