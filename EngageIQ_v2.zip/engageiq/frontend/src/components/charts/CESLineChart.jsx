import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'
import { format, parseISO } from 'date-fns'

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs shadow-xl">
      <p className="text-slate-400 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="font-mono font-semibold">
          {p.name}: {p.value?.toFixed(1)}
        </p>
      ))}
    </div>
  )
}

export default function CESLineChart({ data = [], height = 200 }) {
  const formatted = data.map(d => ({
    ...d,
    time: d.t ? format(parseISO(d.t), 'HH:mm:ss') : '',
  }))
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={formatted} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
        <XAxis dataKey="time" tick={{ fill: '#64748b', fontSize: 10 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 10 }} tickLine={false} axisLine={false} />
        <Tooltip content={<CustomTooltip />} />
        <ReferenceLine y={70} stroke="#10b98144" strokeDasharray="4 4" />
        <ReferenceLine y={40} stroke="#ef444444" strokeDasharray="4 4" />
        <Line type="monotone" dataKey="ces" stroke="#6366f1" strokeWidth={2}
          dot={false} activeDot={{ r: 4, fill: '#6366f1' }}
          name="CES" animationDuration={300} />
      </LineChart>
    </ResponsiveContainer>
  )
}
