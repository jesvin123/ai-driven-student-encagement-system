import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts'

const COLORS = {
  happy: '#10b981', neutral: '#6366f1', surprise: '#f59e0b',
  sad: '#60a5fa', fear: '#a78bfa', angry: '#f87171', disgust: '#fb923c'
}

export default function EmotionPieChart({ data = {}, height = 200 }) {
  const chartData = Object.entries(data).map(([name, value]) => ({ name, value }))
  if (!chartData.length) return (
    <div className="flex items-center justify-center h-32 text-slate-500 text-sm">No data yet</div>
  )
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie data={chartData} cx="50%" cy="50%" innerRadius="45%" outerRadius="70%"
          dataKey="value" nameKey="name" paddingAngle={3}>
          {chartData.map((entry) => (
            <Cell key={entry.name} fill={COLORS[entry.name] || '#6366f1'} />
          ))}
        </Pie>
        <Tooltip formatter={(v, n) => [v, n]} contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12, fontSize: 12 }} />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
      </PieChart>
    </ResponsiveContainer>
  )
}
