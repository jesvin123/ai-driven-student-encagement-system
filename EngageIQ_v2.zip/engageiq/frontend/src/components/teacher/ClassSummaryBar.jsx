import { Users, TrendingUp, AlertTriangle, Wifi, WifiOff } from 'lucide-react'
import { getCESColor } from '../common/CESBadge'

function Stat({ icon: Icon, label, value, color }) {
  return (
    <div className="flex items-center gap-2 px-4 py-2 bg-slate-800/60 rounded-xl border border-slate-700/60">
      <Icon className="w-4 h-4" style={{ color: color || '#6366f1' }} />
      <div>
        <p className="text-xs text-slate-500 leading-none">{label}</p>
        <p className="text-sm font-bold text-white mt-0.5" style={{ color }}>{value}</p>
      </div>
    </div>
  )
}

export default function ClassSummaryBar({ summary, wsConnected, activeStudents = 0 }) {
  const avg = summary?.avg_ces ?? 0
  const color = getCESColor(avg)
  return (
    <div className="flex flex-wrap items-center gap-2 mb-6">
      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
        style={wsConnected ? { background: '#10b98122', color: '#10b981', border: '1px solid #10b98144' }
          : { background: '#ef444422', color: '#ef4444', border: '1px solid #ef444444' }}>
        {wsConnected ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
        {wsConnected ? 'Live' : 'Disconnected'}
      </div>
      <Stat icon={Users} label="Students" value={activeStudents} />
      <Stat icon={TrendingUp} label="Avg CES" value={avg ? avg.toFixed(1) : '—'} color={color} />
      {summary?.disengaged_count > 0 && (
        <Stat icon={AlertTriangle} label="Disengaged" value={summary.disengaged_count} color="#ef4444" />
      )}
    </div>
  )
}
