import { X, Eye, Brain, Activity, TrendingUp, TrendingDown, Minus } from 'lucide-react'
import CESGauge from '../common/CESGauge'
import { getCESColor } from '../common/CESBadge'

function Row({ label, value, color }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-slate-800">
      <span className="text-slate-500 text-sm">{label}</span>
      <span className="text-sm font-semibold" style={{ color: color || '#f1f5f9' }}>{value ?? '—'}</span>
    </div>
  )
}

export default function StudentDetailModal({ student, onClose }) {
  if (!student) return null
  const { label, ces, emotion, gaze_direction, pose_label, attention_score, head_pitch, head_yaw, component_scores, trend, alert_level } = student
  const color = getCESColor(ces)

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div className="relative bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl animate-slide-up"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <h2 className="text-white font-bold text-lg">{label}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 flex gap-6">
          <div className="flex flex-col items-center gap-2">
            <CESGauge ces={ces} size={100} />
            <div className="flex items-center gap-1 text-xs" style={{ color }}>
              {trend === 'rising' && <TrendingUp className="w-3 h-3" />}
              {trend === 'falling' && <TrendingDown className="w-3 h-3" />}
              {trend === 'stable' && <Minus className="w-3 h-3" />}
              <span className="capitalize">{trend}</span>
            </div>
          </div>
          <div className="flex-1">
            <Row label="Emotion" value={emotion} />
            <Row label="Gaze" value={gaze_direction} />
            <Row label="Pose" value={pose_label} />
            <Row label="Attention" value={attention_score != null ? `${attention_score.toFixed(0)}%` : null} />
            <Row label="Head Pitch" value={head_pitch != null ? `${head_pitch.toFixed(1)}°` : null} />
            <Row label="Head Yaw" value={head_yaw != null ? `${head_yaw.toFixed(1)}°` : null} />
          </div>
        </div>
        {component_scores && Object.keys(component_scores).length > 0 && (
          <div className="px-5 pb-5">
            <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Component Scores</p>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(component_scores).map(([k, v]) => (
                <div key={k} className="bg-slate-800 rounded-lg p-2">
                  <p className="text-slate-500 text-xs capitalize">{k}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${v}%`, background: getCESColor(v) }} />
                    </div>
                    <span className="text-xs font-mono font-semibold text-white">{v}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
