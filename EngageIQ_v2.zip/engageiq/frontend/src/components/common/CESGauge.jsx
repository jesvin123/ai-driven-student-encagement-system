import { getCESColor, getCESLabel } from './CESBadge'

export default function CESGauge({ ces = 0, size = 100 }) {
  const color = getCESColor(ces)
  const label = getCESLabel(ces)
  const pct = Math.min(100, Math.max(0, ces))
  const r = (size / 2) - 8
  const circumference = 2 * Math.PI * r
  const strokeDashoffset = circumference - (pct / 100) * circumference
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1e293b" strokeWidth="8" />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={circumference} strokeDashoffset={strokeDashoffset}
          strokeLinecap="round" transform={`rotate(-90 ${size/2} ${size/2})`}
          style={{ transition: 'stroke-dashoffset 0.5s ease, stroke 0.3s ease' }} />
        <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle"
          fill={color} fontSize={size * 0.18} fontFamily="JetBrains Mono" fontWeight="600">{Math.round(ces)}</text>
      </svg>
      <span className="text-xs font-semibold" style={{ color }}>{label}</span>
    </div>
  )
}
