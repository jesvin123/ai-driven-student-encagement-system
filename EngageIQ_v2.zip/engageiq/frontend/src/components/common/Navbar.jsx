import { Link, useLocation, useNavigate } from 'react-router-dom'
import { LayoutDashboard, Users, BarChart3, Settings, LogOut, Brain } from 'lucide-react'
import useAuthStore from '../../store/authStore'
import clsx from 'clsx'

const links = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/sessions', icon: Users, label: 'Sessions' },
  { to: '/analytics', icon: BarChart3, label: 'Analytics' },
  { to: '/settings', icon: Settings, label: 'Settings' },
]

export default function Navbar() {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const { logout, user } = useAuthStore()
  return (
    <nav className="fixed left-0 top-0 h-full w-16 lg:w-60 bg-slate-900 border-r border-slate-700/60 flex flex-col z-50">
      <div className="flex items-center gap-3 px-4 py-5 border-b border-slate-700/60">
        <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center">
          <Brain className="w-5 h-5 text-indigo-400" />
        </div>
        <div className="hidden lg:block">
          <p className="font-bold text-white text-sm leading-tight">EngageIQ</p>
          <p className="text-slate-500 text-xs">v2.0</p>
        </div>
      </div>
      <div className="flex-1 py-4 flex flex-col gap-1 px-2">
        {links.map(({ to, icon: Icon, label }) => (
          <Link key={to} to={to} className={clsx(
            'flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 text-sm font-medium',
            pathname.startsWith(to)
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          )}>
            <Icon className="w-5 h-5 flex-shrink-0" />
            <span className="hidden lg:block">{label}</span>
          </Link>
        ))}
      </div>
      <div className="px-2 pb-4 border-t border-slate-700/60 pt-3">
        <div className="hidden lg:flex items-center gap-2 px-3 py-2 mb-2">
          <div className="w-7 h-7 rounded-full bg-indigo-500/30 flex items-center justify-center text-indigo-300 text-xs font-bold">
            {user?.name?.[0]?.toUpperCase() || 'T'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-xs font-semibold truncate">{user?.name || 'Teacher'}</p>
            <p className="text-slate-500 text-xs truncate">{user?.role}</p>
          </div>
        </div>
        <button onClick={() => { logout(); navigate('/login') }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all text-sm">
          <LogOut className="w-5 h-5 flex-shrink-0" />
          <span className="hidden lg:block">Sign out</span>
        </button>
      </div>
    </nav>
  )
}
