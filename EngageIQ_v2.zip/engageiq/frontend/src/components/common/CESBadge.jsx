import clsx from 'clsx'

export function getCESColor(ces) {
  if (ces >= 70) return '#10b981'
  if (ces >= 50) return '#f59e0b'
  if (ces >= 30) return '#f97316'
  return '#ef4444'
}

export function getCESLabel(ces) {
  if (ces >= 70) return 'Engaged'
  if (ces >= 50) return 'Partial'
  if (ces >= 30) return 'Low'
  return 'Critical'
}

export default function CESBadge({ ces, size = 'md', showLabel = true }) {
  const color = getCESColor(ces)
  const label = getCESLabel(ces)
  const sizes = { sm: 'text-xs px-2 py-0.5', md: 'text-sm px-2.5 py-1', lg: 'text-base px-3 py-1.5' }
  return (
    <span className={clsx('inline-flex items-center gap-1.5 rounded-full font-semibold font-mono', sizes[size])}
      style={{ background: `${color}22`, color, border: `1px solid ${color}55` }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
      {ces?.toFixed(1)}{showLabel && <span className="opacity-80 font-sans text-xs">{label}</span>}
    </span>
  )
}
