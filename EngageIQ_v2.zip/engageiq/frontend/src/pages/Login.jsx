import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Brain, Eye, EyeOff, Loader2, Zap } from 'lucide-react'
import { authAPI } from '../services/api'
import useAuthStore from '../store/authStore'

export default function Login() {
  const navigate = useNavigate()
  const { login } = useAuthStore()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      const res = mode === 'login'
        ? await authAPI.login({ email: form.email, password: form.password })
        : await authAPI.register(form)
      login(res.data.user, res.data.access_token, res.data.refresh_token)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.detail || 'Something went wrong')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-[#020617] flex">
      {/* Left: branding panel */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 p-12 border-r border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/30 border border-indigo-400/40 flex items-center justify-center">
            <Brain className="w-6 h-6 text-indigo-300" />
          </div>
          <span className="text-white font-bold text-xl">EngageIQ</span>
        </div>
        <div>
          <h1 className="text-4xl font-bold text-white leading-tight mb-4">
            Real-time student<br />
            <span className="text-gradient">engagement analysis</span>
          </h1>
          <p className="text-slate-400 text-lg leading-relaxed mb-8">
            Monitor attention, detect disengagement, and act with AI-powered insights — all in real time.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Engagement Score', value: 'CES 0–100', icon: '📊' },
              { label: 'Face + Gaze + Pose', value: '3 ML Modules', icon: '🧠' },
              { label: 'Real-time WebSocket', value: '< 500ms', icon: '⚡' },
              { label: 'Multi-student', value: 'Up to 40', icon: '👥' },
            ].map(f => (
              <div key={f.label} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
                <p className="text-lg mb-1">{f.icon}</p>
                <p className="text-white text-sm font-semibold">{f.value}</p>
                <p className="text-slate-500 text-xs">{f.label}</p>
              </div>
            ))}
          </div>
        </div>
        <p className="text-slate-600 text-sm">EngageIQ v2.0 · AI-Driven Education Analytics</p>
      </div>

      {/* Right: form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <Brain className="w-7 h-7 text-indigo-400" />
            <span className="text-white font-bold text-xl">EngageIQ</span>
          </div>

          <h2 className="text-2xl font-bold text-white mb-1">
            {mode === 'login' ? 'Welcome back' : 'Create account'}
          </h2>
          <p className="text-slate-400 text-sm mb-8">
            {mode === 'login' ? "Sign in to your teacher account" : "Set up your EngageIQ account"}
          </p>

          <form onSubmit={submit} className="flex flex-col gap-4">
            {mode === 'register' && (
              <div>
                <label className="text-xs text-slate-400 font-medium block mb-1.5">Full Name</label>
                <input value={form.name} onChange={e => update('name', e.target.value)} required
                  placeholder="Dr. Jane Smith"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600" />
              </div>
            )}
            <div>
              <label className="text-xs text-slate-400 font-medium block mb-1.5">Email</label>
              <input type="email" value={form.email} onChange={e => update('email', e.target.value)} required
                placeholder="teacher@school.edu"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600" />
            </div>
            <div>
              <label className="text-xs text-slate-400 font-medium block mb-1.5">Password</label>
              <div className="relative">
                <input type={showPw ? 'text' : 'password'} value={form.password} onChange={e => update('password', e.target.value)} required
                  placeholder="••••••••"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 pr-11 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600" />
                <button type="button" onClick={() => setShowPw(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-2.5 text-red-400 text-sm">{error}</div>
            )}
            <button type="submit" disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2 mt-1">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-slate-500 text-sm mt-6">
            {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
            <button onClick={() => { setMode(m => m === 'login' ? 'register' : 'login'); setError('') }}
              className="text-indigo-400 hover:text-indigo-300 font-semibold transition-colors">
              {mode === 'login' ? 'Register' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  )
}
