import { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Camera, CameraOff, Wifi, WifiOff, Brain } from 'lucide-react'
import { StudentWebSocket } from '../services/websocket'
import CESGauge from '../components/common/CESGauge'
import { getCESColor, getCESLabel } from '../components/common/CESBadge'

export default function StudentView() {
  const { sessionId, studentLabel } = useParams()
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const wsRef = useRef(null)
  const [camActive, setCamActive] = useState(false)
  const [wsConnected, setWsConnected] = useState(false)
  const [engagement, setEngagement] = useState(null)
  const [error, setError] = useState('')

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false })
      streamRef.current = stream
      if (videoRef.current) videoRef.current.srcObject = stream
      setCamActive(true)
      setError('')

      // Connect WebSocket and start streaming
      const ws = new StudentWebSocket(sessionId, studentLabel, (data) => {
        if (data.type === 'engagement_update') setEngagement(data)
        if (data.type === 'connected') setWsConnected(true)
      })
      ws.connect(videoRef.current)
      wsRef.current = ws
      setWsConnected(true)
    } catch (e) {
      setError('Camera access denied. Please allow camera permission.')
    }
  }

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach(t => t.stop())
    wsRef.current?.disconnect()
    setCamActive(false)
    setWsConnected(false)
    setEngagement(null)
  }

  useEffect(() => () => stopCamera(), [])

  const ces = engagement?.ces ?? 0
  const color = getCESColor(ces)
  const label = getCESLabel(ces)

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col">
      <div className="flex items-center gap-3 px-6 py-4 border-b border-slate-800">
        <Brain className="w-6 h-6 text-indigo-400" />
        <div>
          <p className="text-white font-bold text-sm">EngageIQ — Student View</p>
          <p className="text-slate-500 text-xs">{studentLabel} · Session {sessionId?.slice(0,8)}</p>
        </div>
        <div className="ml-auto flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full"
          style={wsConnected ? { background:'#10b98122',color:'#10b981',border:'1px solid #10b98144' }
            : { background:'#47556922',color:'#64748b',border:'1px solid #47556944' }}>
          {wsConnected ? <Wifi className="w-3 h-3"/> : <WifiOff className="w-3 h-3"/>}
          {wsConnected ? 'Connected' : 'Offline'}
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-6 max-w-4xl mx-auto w-full">
        {/* Camera */}
        <div className="flex-1">
          <div className="relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-700 aspect-video">
            <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover" />
            {!camActive && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                <CameraOff className="w-12 h-12 text-slate-600" />
                <p className="text-slate-500 text-sm">Camera is off</p>
              </div>
            )}
            {camActive && wsConnected && (
              <div className="absolute top-3 right-3 px-2 py-1 rounded-full text-xs font-semibold"
                style={{ background:'#ef444422', color:'#ef4444', border:'1px solid #ef444444' }}>
                ● LIVE
              </div>
            )}
          </div>
          {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
          <div className="flex gap-3 mt-4">
            {!camActive ? (
              <button onClick={startCamera}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm transition-all">
                <Camera className="w-4 h-4" /> Start Camera
              </button>
            ) : (
              <button onClick={stopCamera}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30 font-semibold text-sm transition-all">
                <CameraOff className="w-4 h-4" /> Stop Camera
              </button>
            )}
          </div>
        </div>

        {/* Engagement panel */}
        <div className="lg:w-64 flex flex-col gap-4">
          <div className="card p-5 flex flex-col items-center gap-4">
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider w-full">Your Engagement</p>
            <CESGauge ces={ces} size={120} />
            {engagement && (
              <div className="w-full space-y-2">
                {[
                  ['Emotion', engagement.emotion],
                  ['Gaze', engagement.gaze_direction],
                  ['Pose', engagement.pose_label],
                  ['Attention', engagement.attention_score != null ? `${engagement.attention_score.toFixed(0)}%` : null],
                ].map(([k, v]) => v != null && (
                  <div key={k} className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">{k}</span>
                    <span className="text-white font-semibold capitalize">{v}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tips */}
          <div className="card p-4">
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3">Tips</p>
            <ul className="space-y-2 text-xs text-slate-500">
              <li>• Look directly at your camera for best results</li>
              <li>• Ensure your face is well-lit</li>
              <li>• Keep your head relatively still</li>
              <li>• Your teacher can see your engagement score</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
