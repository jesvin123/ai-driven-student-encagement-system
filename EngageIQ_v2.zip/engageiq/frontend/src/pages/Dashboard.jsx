import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Play, Pause, Square, ChevronRight, Clock, BookOpen, Users, TrendingUp } from 'lucide-react'
import { sessionAPI } from '../services/api'
import useAuthStore from '../store/authStore'
import useSessionStore from '../store/sessionStore'
import { getCESColor, getCESLabel } from '../components/common/CESBadge'
import { formatDistanceToNow } from 'date-fns'
import clsx from 'clsx'

function StatusPill({ status }) {
  const cfg = {
    active:  { bg: '#10b98122', color: '#10b981', border: '#10b98144', label: 'Live' },
    pending: { bg: '#6366f122', color: '#818cf8', border: '#6366f144', label: 'Ready' },
    paused:  { bg: '#f59e0b22', color: '#f59e0b', border: '#f59e0b44', label: 'Paused' },
    ended:   { bg: '#47556922', color: '#64748b', border: '#47556944', label: 'Ended' },
  }
  const c = cfg[status] || cfg.pending
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: c.bg, color: c.color, border: `1px solid ${c.border}` }}>
      {status === 'active' && <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />}
      {c.label}
    </span>
  )
}

function SessionCard({ session, onAction }) {
  const [acting, setActing] = useState(false)
  const action = async (type) => {
    setActing(true)
    try { await onAction(session.id, type) } finally { setActing(false) }
  }
  const ces = session.avg_ces
  const cesColor = ces ? getCESColor(ces) : '#6366f1'
  return (
    <div className="card p-5 flex flex-col gap-4 hover:border-slate-600 transition-colors">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <StatusPill status={session.status} />
            {ces && <span className="text-xs font-mono font-bold" style={{ color: cesColor }}>CES {ces.toFixed(1)}</span>}
          </div>
          <h3 className="text-white font-bold text-base truncate">{session.subject}</h3>
          {session.grade && <p className="text-slate-500 text-xs">{session.grade}</p>}
        </div>
        <Link to={`/sessions/${session.id}`}
          className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-all flex-shrink-0">
          <ChevronRight className="w-4 h-4" />
        </Link>
      </div>
      <div className="flex items-center gap-4 text-xs text-slate-500">
        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />
          {session.created_at ? formatDistanceToNow(new Date(session.created_at), { addSuffix: true }) : '—'}
        </span>
        <span className="flex items-center gap-1"><Users className="w-3 h-3" />{session.student_count || 0} students</span>
      </div>
      <div className="flex gap-2">
        {session.status === 'pending' && (
          <button onClick={() => action('start')} disabled={acting}
            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all disabled:opacity-60">
            <Play className="w-3.5 h-3.5" /> Start
          </button>
        )}
        {session.status === 'active' && (
          <>
            <Link to={`/sessions/${session.id}/monitor`}
              className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all">
              <TrendingUp className="w-3.5 h-3.5" /> Monitor
            </Link>
            <button onClick={() => action('end')} disabled={acting}
              className="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 text-sm font-semibold transition-all border border-red-500/30 disabled:opacity-60">
              <Square className="w-3.5 h-3.5" />
            </button>
          </>
        )}
        {session.status === 'paused' && (
          <button onClick={() => action('start')} disabled={acting}
            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-sm font-semibold border border-amber-500/30 transition-all disabled:opacity-60">
            <Play className="w-3.5 h-3.5" /> Resume
          </button>
        )}
        {session.status === 'ended' && (
          <Link to={`/sessions/${session.id}`}
            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-all">
            View Report
          </Link>
        )}
      </div>
    </div>
  )
}

function CreateModal({ onClose, onCreate }) {
  const [form, setForm] = useState({ subject: '', grade: '', description: '' })
  const [loading, setLoading] = useState(false)
  const submit = async (e) => {
    e.preventDefault(); setLoading(true)
    try { await onCreate(form); onClose() } finally { setLoading(false) }
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div className="relative bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl animate-slide-up" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-800 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          <h2 className="text-white font-bold">New Session</h2>
        </div>
        <form onSubmit={submit} className="p-5 flex flex-col gap-4">
          <div>
            <label className="text-xs text-slate-400 font-medium block mb-1.5">Subject *</label>
            <input required value={form.subject} onChange={e => setForm(f=>({...f,subject:e.target.value}))}
              placeholder="e.g. Mathematics, Physics, History"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600" />
          </div>
          <div>
            <label className="text-xs text-slate-400 font-medium block mb-1.5">Grade / Class</label>
            <input value={form.grade} onChange={e => setForm(f=>({...f,grade:e.target.value}))}
              placeholder="e.g. Grade 10, Class B"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600" />
          </div>
          <div>
            <label className="text-xs text-slate-400 font-medium block mb-1.5">Notes</label>
            <textarea value={form.description} onChange={e => setForm(f=>({...f,description:e.target.value}))}
              placeholder="Optional session notes..."
              rows={2}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600 resize-none" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-sm font-semibold transition-all">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all disabled:opacity-60">
              {loading ? 'Creating...' : 'Create Session'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { user } = useAuthStore()
  const { sessions, setSessions, updateSession } = useSessionStore()
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)

  const load = async () => {
    try { const r = await sessionAPI.list(); setSessions(r.data) } catch {}
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  const handleAction = async (id, type) => {
    try {
      if (type === 'start') await sessionAPI.start(id)
      else if (type === 'end') await sessionAPI.end(id)
      else if (type === 'pause') await sessionAPI.pause(id)
      await load()
    } catch (e) { console.error(e) }
  }

  const handleCreate = async (data) => {
    await sessionAPI.create(data)
    await load()
  }

  const active = sessions.filter(s => s.status === 'active')
  const others = sessions.filter(s => s.status !== 'active')

  return (
    <div className="flex-1 p-6 lg:p-8 overflow-auto">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">
              Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'},
              {' '}<span className="text-gradient">{user?.name?.split(' ')[0] || 'Teacher'}</span>
            </h1>
            <p className="text-slate-400 text-sm mt-1">Manage your class sessions and monitor student engagement</p>
          </div>
          <button onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all shadow-lg shadow-indigo-500/20">
            <Plus className="w-4 h-4" /> New Session
          </button>
        </div>

        {/* Active sessions */}
        {active.length > 0 && (
          <div className="mb-8">
            <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3">🔴 Active Now</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {active.map(s => <SessionCard key={s.id} session={s} onAction={handleAction} />)}
            </div>
          </div>
        )}

        {/* All sessions */}
        <div>
          <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3">All Sessions</h2>
          {loading ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[1,2,3].map(i => <div key={i} className="card p-5 h-40 animate-pulse" />)}
            </div>
          ) : others.length === 0 && active.length === 0 ? (
            <div className="card p-12 flex flex-col items-center gap-4 text-center">
              <BookOpen className="w-12 h-12 text-slate-600" />
              <div>
                <p className="text-white font-semibold">No sessions yet</p>
                <p className="text-slate-500 text-sm mt-1">Create your first session to start monitoring student engagement</p>
              </div>
              <button onClick={() => setShowCreate(true)}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all">
                Create Session
              </button>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {others.map(s => <SessionCard key={s.id} session={s} onAction={handleAction} />)}
            </div>
          )}
        </div>
      </div>
      {showCreate && <CreateModal onClose={() => setShowCreate(false)} onCreate={handleCreate} />}
    </div>
  )
}
