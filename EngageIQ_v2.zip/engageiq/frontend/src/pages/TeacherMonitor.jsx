import { useEffect, useRef, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Square, RefreshCw, Bell, BellOff, Maximize2 } from 'lucide-react'
import { TeacherWebSocket } from '../services/websocket'
import { sessionAPI } from '../services/api'
import useEngagementStore from '../store/engagementStore'
import ClassroomGrid from '../components/engagement/ClassroomGrid'
import ClassSummaryBar from '../components/teacher/ClassSummaryBar'
import AlertBanner from '../components/engagement/AlertBanner'
import StudentDetailModal from '../components/teacher/StudentDetailModal'
import CESLineChart from '../components/charts/CESLineChart'

// Alert generation logic
function checkAlerts(students, classSummary) {
  const alerts = []
  const list = Object.values(students)
  const criticals = list.filter(s => s.alert_level === 'critical')
  if (criticals.length >= 3) {
    alerts.push({ level: 'critical', title: `${criticals.length} students critically disengaged`, message: 'Consider pausing and re-engaging the class.' })
  }
  if (classSummary?.avg_ces != null && classSummary.avg_ces < 45) {
    alerts.push({ level: 'warning', title: `Class CES dropped to ${classSummary.avg_ces.toFixed(0)}`, message: 'Overall engagement is low — try a quick activity or break.' })
  }
  return alerts
}

export default function TeacherMonitor() {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const wsRef = useRef(null)
  const { students, classSummary, alerts, wsConnected,
    updateStudent, setClassSummary, addAlert, clearAlerts, setWsConnected, reset } = useEngagementStore()
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [alertsMuted, setAlertsMuted] = useState(false)
  const [cesHistory, setCesHistory] = useState([])
  const [session, setSession] = useState(null)

  useEffect(() => {
    sessionAPI.get(sessionId).then(r => setSession(r.data)).catch(() => {})
  }, [sessionId])

  const handleWsMessage = useCallback((msg) => {
    if (!msg) return
    if (msg.type === 'connected') { setWsConnected(true); return }
    if (msg.type === 'heartbeat' || msg.type === 'pong') {
      if (msg.class_summary) setClassSummary(msg.class_summary)
      return
    }
    if (msg.type === 'initial_state') {
      msg.students?.forEach(s => updateStudent(s.student_label, s))
      return
    }
    if (msg.type === 'student_update') {
      updateStudent(msg.student_label, msg)
      // track class CES history
      if (msg.ces != null) {
        setCesHistory(prev => [...prev.slice(-60), { t: msg.timestamp, ces: msg.ces }])
      }
    }
  }, [updateStudent, setClassSummary, setWsConnected])

  useEffect(() => {
    reset()
    const ws = new TeacherWebSocket(sessionId, handleWsMessage)
    ws.connect()
    wsRef.current = ws
    const ping = setInterval(() => ws.ping(), 25000)
    return () => { clearInterval(ping); ws.disconnect(); reset() }
  }, [sessionId])

  // Auto-generate alerts
  useEffect(() => {
    if (alertsMuted) return
    const newAlerts = checkAlerts(students, classSummary)
    newAlerts.forEach(a => addAlert(a))
  }, [classSummary?.avg_ces])

  const handleEndSession = async () => {
    if (!confirm('End this session? This will finalize the engagement report.')) return
    await sessionAPI.end(sessionId)
    navigate(`/sessions/${sessionId}`)
  }

  const studentList = Object.values(students)

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Top bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950 flex-shrink-0">
        <div>
          <h1 className="text-white font-bold text-lg">{session?.subject || 'Live Monitor'}</h1>
          <p className="text-slate-500 text-xs">{session?.grade && `${session.grade} · `}Session ID: {sessionId.slice(0,8)}...</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setAlertsMuted(v=>!v)}
            className="p-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 transition-all"
            title={alertsMuted ? 'Unmute alerts' : 'Mute alerts'}>
            {alertsMuted ? <BellOff className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
          </button>
          <button onClick={handleEndSession}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 text-sm font-semibold transition-all">
            <Square className="w-3.5 h-3.5" /> End Session
          </button>
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-auto p-6">
        <AlertBanner alerts={alerts} onDismiss={(i) => {
          const updated = [...alerts]; updated.splice(i, 1)
          useEngagementStore.setState({ alerts: updated })
        }} />

        <ClassSummaryBar summary={classSummary} wsConnected={wsConnected} activeStudents={studentList.length} />

        {/* CES history chart */}
        {cesHistory.length > 2 && (
          <div className="card p-4 mb-6">
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3">Class Engagement Trend</p>
            <CESLineChart data={cesHistory} height={120} />
          </div>
        )}

        {/* Classroom grid */}
        <ClassroomGrid students={students} onStudentClick={setSelectedStudent} />
      </div>

      {selectedStudent && (
        <StudentDetailModal student={selectedStudent} onClose={() => setSelectedStudent(null)} />
      )}
    </div>
  )
}
