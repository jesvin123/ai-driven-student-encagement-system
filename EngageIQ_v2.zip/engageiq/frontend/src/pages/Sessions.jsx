import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { sessionAPI } from '../services/api'
import useSessionStore from '../store/sessionStore'
import { Plus, ChevronRight, BookOpen } from 'lucide-react'
import { getCESColor } from '../components/common/CESBadge'
import { format } from 'date-fns'

export default function Sessions() {
  const { sessions, setSessions } = useSessionStore()
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    sessionAPI.list().then(r => setSessions(r.data)).catch(()=>{}).finally(() => setLoading(false))
  }, [])
  return (
    <div className="flex-1 p-6 lg:p-8 overflow-auto">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">Sessions</h1>
            <p className="text-slate-400 text-sm mt-1">All class sessions</p>
          </div>
          <Link to="/dashboard" className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all">
            <Plus className="w-4 h-4" /> New
          </Link>
        </div>
        {loading ? (
          <div className="space-y-3">{[1,2,3].map(i=><div key={i} className="card h-16 animate-pulse"/>)}</div>
        ) : sessions.length === 0 ? (
          <div className="card p-12 flex flex-col items-center gap-4 text-center">
            <BookOpen className="w-12 h-12 text-slate-600" />
            <p className="text-slate-500 text-sm">No sessions yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sessions.map(s => (
              <Link key={s.id} to={`/sessions/${s.id}`} className="card p-4 flex items-center gap-4 hover:border-slate-600 transition-all">
                <div className="flex-1 min-w-0">
                  <p className="text-white font-semibold truncate">{s.subject}</p>
                  <p className="text-slate-500 text-xs">{s.grade && `${s.grade} · `}{format(new Date(s.created_at), 'MMM d, yyyy')}</p>
                </div>
                <div className="flex items-center gap-3">
                  {s.avg_ces && <span className="text-sm font-bold font-mono" style={{color:getCESColor(s.avg_ces)}}>{s.avg_ces.toFixed(1)}</span>}
                  <span className="text-xs capitalize px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">{s.status}</span>
                  <ChevronRight className="w-4 h-4 text-slate-600" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
