import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, Play, TrendingUp, Clock, Users, BarChart3, Link2 } from 'lucide-react'
import { sessionAPI, analyticsAPI } from '../services/api'
import CESGauge from '../components/common/CESGauge'
import CESLineChart from '../components/charts/CESLineChart'
import EmotionPieChart from '../components/charts/EmotionPieChart'
import GazeBarChart from '../components/charts/GazeBarChart'
import { getCESColor } from '../components/common/CESBadge'

export default function SessionDetail() {
  const { sessionId } = useParams()
  const [session, setSession] = useState(null)
  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      sessionAPI.get(sessionId),
      analyticsAPI.sessionSummary(sessionId),
    ]).then(([sRes, rRes]) => {
      setSession(sRes.data)
      setReport(rRes.data)
    }).catch(() => {}).finally(() => setLoading(false))
  }, [sessionId])

  const studentUrl = `${window.location.origin}/student/${sessionId}`

  if (loading) return (
    <div className="flex-1 p-8 flex items-center justify-center">
      <div className="text-slate-500 text-sm">Loading session...</div>
    </div>
  )

  if (!session) return (
    <div className="flex-1 p-8 flex items-center justify-center">
      <div className="text-slate-500 text-sm">Session not found</div>
    </div>
  )

  const ces = session.avg_ces
  const cesColor = ces ? getCESColor(ces) : '#6366f1'

  return (
    <div className="flex-1 p-6 lg:p-8 overflow-auto">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link to="/sessions" className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white">{session.subject}</h1>
            <p className="text-slate-400 text-sm">{session.grade && `${session.grade} · `}
              <span className="capitalize">{session.status}</span>
            </p>
          </div>
          {session.status === 'active' && (
            <Link to={`/sessions/${sessionId}/monitor`}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all">
              <TrendingUp className="w-4 h-4" /> Open Monitor
            </Link>
          )}
        </div>

        {/* Student join link */}
        <div className="card p-4 mb-6 flex items-center gap-4">
          <Link2 className="w-5 h-5 text-indigo-400 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-400 mb-1">Student Join Link</p>
            <p className="text-sm text-indigo-300 font-mono truncate">{studentUrl}/{'{your-name}'}</p>
          </div>
          <button onClick={() => navigator.clipboard.writeText(studentUrl + '/Student')}
            className="px-3 py-1.5 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold hover:bg-indigo-500/30 transition-all">
            Copy
          </button>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Avg CES', value: ces ? ces.toFixed(1) : '—', icon: BarChart3, color: cesColor },
            { label: 'Total Events', value: report?.total_events ?? 0, icon: TrendingUp, color: '#6366f1' },
            { label: 'Status', value: session.status, icon: Play, color: '#10b981' },
            { label: 'Duration', value: session.start_time
              ? session.end_time
                ? `${Math.round((new Date(session.end_time)-new Date(session.start_time))/60000)}m`
                : 'Ongoing'
              : 'Not started', icon: Clock, color: '#f59e0b' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="card p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4" style={{ color }} />
                <span className="text-xs text-slate-500 uppercase tracking-wide">{label}</span>
              </div>
              <p className="text-xl font-bold capitalize" style={{ color }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Charts */}
        {report?.ces_timeline?.length > 0 && (
          <div className="card p-5 mb-6">
            <h3 className="text-white font-semibold mb-4">CES Timeline</h3>
            <CESLineChart data={report.ces_timeline} height={200} />
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {report?.emotion_distribution && Object.keys(report.emotion_distribution).length > 0 && (
            <div className="card p-5">
              <h3 className="text-white font-semibold mb-4">Emotion Distribution</h3>
              <EmotionPieChart data={report.emotion_distribution} />
            </div>
          )}
          {report?.gaze_distribution && Object.keys(report.gaze_distribution).length > 0 && (
            <div className="card p-5">
              <h3 className="text-white font-semibold mb-4">Gaze Distribution</h3>
              <GazeBarChart data={report.gaze_distribution} />
            </div>
          )}
        </div>

        {/* No data yet */}
        {(!report || report.total_events === 0) && (
          <div className="card p-12 flex flex-col items-center gap-4 text-center">
            <BarChart3 className="w-12 h-12 text-slate-600" />
            <div>
              <p className="text-white font-semibold">No engagement data yet</p>
              <p className="text-slate-500 text-sm mt-1">Start the session and connect students to see analytics here</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
