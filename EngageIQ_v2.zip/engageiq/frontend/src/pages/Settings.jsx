import { useState } from 'react'
import useAuthStore from '../store/authStore'
import { User, Key, Bell, Shield } from 'lucide-react'
export default function Settings() {
  const { user } = useAuthStore()
  return (
    <div className="flex-1 p-6 lg:p-8 overflow-auto">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold text-white mb-1">Settings</h1>
        <p className="text-slate-400 text-sm mb-8">Manage your account and preferences</p>
        <div className="card p-5 mb-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-indigo-500/30 flex items-center justify-center text-indigo-300 font-bold text-lg">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <p className="text-white font-semibold">{user?.name}</p>
            <p className="text-slate-400 text-sm">{user?.email}</p>
            <p className="text-slate-500 text-xs capitalize mt-0.5">{user?.role}</p>
          </div>
        </div>
        {[
          { icon: User, label: 'Profile', desc: 'Update your name and email' },
          { icon: Key, label: 'Password', desc: 'Change your password' },
          { icon: Bell, label: 'Notifications', desc: 'Alert thresholds and preferences' },
          { icon: Shield, label: 'Privacy', desc: 'Data retention and privacy settings' },
        ].map(({ icon: Icon, label, desc }) => (
          <div key={label} className="card p-4 mb-3 flex items-center gap-4 opacity-60 cursor-not-allowed">
            <Icon className="w-5 h-5 text-indigo-400" />
            <div className="flex-1"><p className="text-white font-semibold text-sm">{label}</p><p className="text-slate-500 text-xs">{desc}</p></div>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-500">Soon</span>
          </div>
        ))}
      </div>
    </div>
  )
}
