import { useEffect, useState } from 'react'
import { analyticsAPI } from '../services/api'
import { BarChart3, TrendingUp, BookOpen, Clock } from 'lucide-react'
import { getCESColor } from '../components/common/CESBadge'
import { format } from 'date-fns'

function SessionRow({ session }) {
  const ces = session.avg_ces
  const color = ces ? getCESColor(ces) : '#6366f1'
  return (
    <div className="flex items-center justify-between py-3 border-b border-slate-800 last:border-0">
      <div className="flex-1 min-w-0">
        <p className="text-white font-semibold text-sm truncate">{session.subject}</p>
        <p className="text-slate-500 text-xs">{session.start_time ? format(new Date(session.start_time), 'MMM d, HH:mm') : format(new Date(session.created_at), 'MMM d')}</p>
      </div>
      <div className="flex items-center gap-3">
        <span className="capitalize text-xs px-2 py-0.5 rounded-full" style={{
          background: session.status === 'ended' ? '#47556922' : '#10b98122',
          color: session.status === 'ended' ? '#64748b' : '#10b981',
        }}>{session.status}</span>
        {ces && (
          <span className="text-sm font-bold font-mono" style={{ color }}>{ces.toFixed(1)}</span>
        )}
      </div>
    </div>
  )
}

export default function Analytics() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    analyticsAPI.overview().then(r => setData(r.data)).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const sessions = data?.sessions || []
  const ended = sessions.filter(s => s.status === 'ended' && s.avg_ces)
  const avgCES = ended.length ? ended.reduce((a,s) => a + s.avg_ces, 0) / ended.length : null

  return (
    <div className="flex-1 p-6 lg:p-8 overflow-auto">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-white mb-1">Analytics</h1>
        <p className="text-slate-400 text-sm mb-8">Engagement insights across all your sessions</p>

        {/* Summary cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Sessions', value: data?.total_sessions ?? '—', icon: BookOpen, color: '#6366f1' },
            { label: 'Completed', value: ended.length, icon: TrendingUp, color: '#10b981' },
            { label: 'Avg Class CES', value: avgCES ? avgCES.toFixed(1) : '—', icon: BarChart3, color: avgCES ? getCESColor(avgCES) : '#6366f1' },
            { label: 'Active Now', value: sessions.filter(s=>s.status==='active').length, icon: Clock, color: '#f59e0b' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="card p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4" style={{ color }} />
                <span className="text-xs text-slate-500 uppercase tracking-wide">{label}</span>
              </div>
              <p className="text-2xl font-bold" style={{ color }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Session list */}
        <div className="card p-5">
          <h2 className="text-white font-semibold mb-4">Session History</h2>
          {loading ? (
            <div className="space-y-3">
              {[1,2,3,4].map(i => <div key={i} className="h-10 bg-slate-800 rounded-lg animate-pulse" />)}
            </div>
          ) : sessions.length === 0 ? (
            <p className="text-slate-500 text-sm py-8 text-center">No sessions yet. Create your first session to see analytics.</p>
          ) : (
            <div>{sessions.map(s => <SessionRow key={s.id} session={s} />)}</div>
          )}
        </div>
      </div>
    </div>
  )
}
