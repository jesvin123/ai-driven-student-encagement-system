import { useRef, useState, useCallback, useEffect } from 'react'

/**
 * Hook to manage webcam stream and capture frames as base64 JPEG.
 */
export function useWebcam({ onFrame, fps = 5, enabled = false }) {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const streamRef = useRef(null)
  const intervalRef = useRef(null)

  const [active, setActive] = useState(false)
  const [error, setError] = useState(null)
  const [hasPermission, setHasPermission] = useState(null)

  const start = useCallback(async () => {
    try {
      setError(null)
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: 'user' },
        audio: false,
      })
      streamRef.current = stream
      setHasPermission(true)

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }

      setActive(true)
    } catch (err) {
      setError(err.message || 'Camera access denied')
      setHasPermission(false)
    }
  }, [])

  const stop = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop())
      streamRef.current = null
    }
    if (videoRef.current) videoRef.current.srcObject = null
    setActive(false)
  }, [])

  const captureFrame = useCallback(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas || video.readyState < 2) return null

    canvas.width = 320
    canvas.height = 240
    const ctx = canvas.getContext('2d')
    ctx.drawImage(video, 0, 0, 320, 240)
    // Strip "data:image/jpeg;base64," prefix
    return canvas.toDataURL('image/jpeg', 0.7).split(',')[1]
  }, [])

  // Send frames at specified FPS when active and callback provided
  useEffect(() => {
    if (!active || !enabled || !onFrame) return
    const ms = Math.round(1000 / fps)
    intervalRef.current = setInterval(() => {
      const frame = captureFrame()
      if (frame) onFrame(frame)
    }, ms)
    return () => clearInterval(intervalRef.current)
  }, [active, enabled, fps, onFrame, captureFrame])

  // Cleanup on unmount
  useEffect(() => () => stop(), [stop])

  return { videoRef, canvasRef, active, error, hasPermission, start, stop, captureFrame }
}
