import { useEffect, useRef, useState, useCallback } from 'react'
import { TeacherSocket } from '../services/websocket'
import useAuthStore from '../store/authStore'

/**
 * Hook for teacher dashboard — connects WebSocket and maintains live engagement state.
 */
export function useTeacherSocket(sessionId) {
  const { accessToken } = useAuthStore()
  const socketRef = useRef(null)

  const [connected, setConnected] = useState(false)
  const [studentCes, setStudentCes] = useState({})      // { student_id: ces }
  const [classSummary, setClassSummary] = useState(null)
  const [alerts, setAlerts] = useState([])
  const [lastUpdate, setLastUpdate] = useState(null)

  const handleMessage = useCallback((msg) => {
    switch (msg.type) {
      case 'connected':
        setConnected(true)
        setStudentCes(msg.current_ces || {})
        setAlerts(msg.alerts || [])
        break

      case 'student_update':
        setStudentCes((prev) => ({ ...prev, [msg.student_id]: msg.ces }))
        setLastUpdate(msg)
        if (msg.alert) {
          setAlerts((prev) => [
            { ...msg.alert, student_id: msg.student_id, id: Date.now() },
            ...prev.slice(0, 19),
          ])
        }
        break

      case 'class_summary':
        setClassSummary(msg.summary)
        setStudentCes(msg.student_ces || {})
        setAlerts(msg.alerts || [])
        break

      case 'pong':
        break

      default:
        break
    }
  }, [])

  useEffect(() => {
    if (!sessionId || !accessToken) return

    const socket = new TeacherSocket(sessionId, accessToken, handleMessage)
    socket.connect()
    socketRef.current = socket

    return () => {
      socket.disconnect()
      setConnected(false)
    }
  }, [sessionId, accessToken, handleMessage])

  const dismissAlert = useCallback((id) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id))
  }, [])

  return { connected, studentCes, classSummary, alerts, lastUpdate, dismissAlert }
}
