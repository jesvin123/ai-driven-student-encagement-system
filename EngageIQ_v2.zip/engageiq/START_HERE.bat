@echo off
echo =====================================================
echo   EngageIQ - AI Student Engagement System v2.0
echo   Windows Quick-Start
echo =====================================================
echo.
echo This script will start both Backend and Frontend.
echo.
echo [STEP 1] Checking Python...
python --version 2>NUL
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.11+ from python.org
    pause & exit /b 1
)
echo [STEP 2] Checking Node.js...
node --version 2>NUL
if errorlevel 1 (
    echo ERROR: Node.js not found. Install Node.js 18+ from nodejs.org
    pause & exit /b 1
)
echo.
echo [INFO] Starting Backend in new window...
start "EngageIQ Backend" cmd /k "cd backend && call start.bat"
timeout /t 5 /nobreak >NUL
echo [INFO] Starting Frontend in new window...
start "EngageIQ Frontend" cmd /k "cd frontend && npm install && npm run dev"
echo.
echo =====================================================
echo   Both services starting...
echo.
echo   Backend API:   http://localhost:8000
echo   API Docs:      http://localhost:8000/docs
echo   Frontend:      http://localhost:5173
echo.
echo   Open http://localhost:5173 in your browser
echo =====================================================
pause
